# Loop 2 — Status, Delivery and Pay (V2)

Part of the Tailor Shop Manager PRD v1.0 · Build only this loop, on top of a finished Loop 1 · Also read the App Map, and continue from the current app (section 0)

## 0. Continue from what exists (read first)

This loop continues one app. With this document you receive the **App Map** and the **current app** (design and code) as the last loop left it.

- Never create a second copy of a screen or component that already exists. Open the existing one and change it **in place**.
- Keep the existing navigation, layout, colours and wording. Do not restyle, rename or regenerate earlier work.
- Anything new must look like it was always part of the app. Reuse the existing cards, badges, buttons, forms, dialogs, tabs, and empty and loading states.
- Each item below is marked **EXISTING** (leave alone), **EXTEND** (change in place, exactly as listed) or **NEW** (create).
- If you cannot find an existing screen or component, stop and ask me. Do not recreate it.

**EXISTING (leave alone):** app shell and navigation, New / Edit Order form (except the one line below), Settings (Items & Prices, Default discount type, Ribbon values), the delete flow, search and sort.

**EXTEND (change in place):**
- **Orders screen:** add a **Delivery** button beside New Order; add the two **summary cards** above the list; add the **tabs**.
- **Order card:** the status badge becomes a **status dropdown**; add the **Pay** button for Delivered orders with a due.
- **Order Details:** add the status dropdown, delivered date, Payments section and Pay button.
- **New / Edit Order form:** add the read-only "Received later" line under Advance.
- **Settings:** add **Upcoming delivery days**.

**NEW:** the **Delivery** screen and the **Pay** confirmation dialog.

## 1. Purpose and rules for the builder

Loop 2 makes an order move through its life: Pending, Cutting Slip – Done, Delivered, then fully paid. When this works end to end, the loop is done.

**Rules**

- Build only what is written here, on top of Loop 1. Do not change Loop 1 behaviour except where section 3 says so.
- If something is not in this document, leave it out and tell me what you left out. If something is unclear, ask.
- Officer orders only. No login, one shared database.
- Never write the word "optional" anywhere in the screen text.

## 2. What is new in this loop

1. A working **status** on every order.
2. **Tabs** and two **summary cards** on the Orders screen.
3. A separate **Delivery** screen.
4. A **Pay** button with payment records.
5. A new Settings item: **Upcoming delivery days**.

## 3. What changes from Loop 1

- The status badge (always "Pending") becomes a **status dropdown** on the order card and on Order Details.
- **Due** is now: Total − Discount − Advance − all Pay amounts received so far.
- Order Details gets a delivered date, a Payments section and a Pay button.
- The Orders screen header gets a **Delivery** button beside New Order.
- The edit form shows a read-only line "Received later: ৳X" under Advance when the order has Pay records.

## 4. Status

- Three statuses: **Pending** (orange), **Cutting Slip – Done** (purple), **Delivered** (green).
- Changed from the dropdown on the card or on Order Details. **Any direction is allowed**, including back from Delivered to Pending, and straight from Pending to Delivered.
- When set to Delivered, save **today as the delivered date**. When moved away from Delivered, **clear the delivered date**.
- Pay records are never touched by a status change.
- A status change saves immediately, with no extra confirmation. Show a short message such as "Order #12 is now Delivered".

## 5. Orders screen additions

### 5.1 Summary cards (top of the screen)

- **Upcoming to Deliver:** the number of orders that are not Delivered and whose delivery date is from today up to today plus the Upcoming delivery days number from Settings. Orders without a delivery date are not counted.
- **Due After Delivery:** the total taka of Due on Delivered orders where Due is above 0, plus how many such orders there are (for example "৳86,712 · 71 orders").
- Tapping a card filters the list to the orders behind it, and shows a small chip such as "Filter: Upcoming ✕". Tapping the chip clears it.

### 5.2 Tabs

- **All**, **Pending**, **Cutting Slip – Done**, **Delivered**, each with its order count.
- The tab, the search box, the sort dropdown and a card filter all work together.

### 5.3 Order card

- The status badge is the dropdown from section 4.
- Card still shows order number, "Officer" badge, name, BD number, dates, Total, Advance and Due.
- **Pay button:** shown only when the status is Delivered and Due is above 0, reading "Pay ৳300" with the real Due.

## 6. Delivery screen

- Opened by the **Delivery** button next to New Order. Has a back button.
- A search box: name, phone, BD number or order number.
- The list shows only orders that are **not yet Delivered** (Pending and Cutting Slip – Done), Officer orders for now.
- Each row: order number, name, BD number, delivery date, Due, and a **Deliver** button.
- Tapping **Deliver** sets the order to Delivered with today’s date, removes the row, and shows "Order #12 delivered".
- Empty state: "Nothing waiting for delivery."
- This screen is a shortcut only. Changing the status dropdown on an order does the same thing.

## 7. Pay

- Shown only on a **Delivered** order with Due above 0, on the card and on Order Details.
- Means "I received the remaining money in cash". It is not an online payment. No partial payments.
- Tapping Pay opens a dialog: "Receive ৳300 from NAME for order #12?" with **Cancel** and **Received**.
- On **Received**: store a payment record (amount equal to the whole Due, today’s date), Due becomes 0, the Pay button disappears, and the card’s Due is no longer red.
- Order Details has a **Payments** section listing: Advance (from the order date), then each Pay record with its date and amount, and a total received line.

## 8. Editing an order after delivery or payment

- Any order can be edited at any time, including Delivered and paid ones.
- Example: an order of ৳500 was paid in full and delivered. The owner edits it and adds another ৳500 item. Total becomes 1000, the ৳500 already received stays, Due becomes ৳500 and the Pay button appears again. The old payment record stays visible.
- The Total can still be typed over by hand while editing, as in Loop 1, and Due recalculates.
- **If the money already received is more than the new total**, do not save. Show: "The money already received is more than the total. Please check the amounts." Due is never shown as negative.
- A paid order edited back to Due 0 simply shows no Pay button.

## 9. Delete

Same two-step delete and the same order-number closing as Loop 1. Deleting an order also deletes its payment records.

## 10. Settings addition

- **Upcoming delivery days:** a whole number, default 3. Used by the Upcoming to Deliver card.

## 11. Data additions

- **Order:** delivered date (empty unless Delivered), status is now Pending, Cutting Slip – Done or Delivered.
- **Payment record:** which order, amount, date.
- **Settings:** upcoming delivery days.

## 12. User flows

**A. Normal order life.** New order (Loop 1) → status Pending → tailor finishes the cloth → set Cutting Slip – Done → customer collects → set Delivered (or use the Delivery screen) → if Due above 0, press Pay → Due 0.

**B. Quick delivery.** Tap Delivery → search the customer’s BD number → tap Deliver → the order is Delivered. If Due is above 0, go back to Orders and press Pay.

**C. Collect the rest of the money.** Orders → tap the Due After Delivery card → only owing orders show → press Pay on one → confirm → the card total drops.

**D. What is due soon?** Tap the Upcoming to Deliver card → see the orders to finish and deliver in the next days.

**E. Customer adds items later.** Open the delivered order → Edit Order → add items → Update Order → Due shows the difference → Pay appears again.

**F. Mistake.** Marked Delivered by accident → change the dropdown back to Pending. The delivered date clears. If a Pay was pressed by mistake, the record cannot be removed in this loop; ask the owner to edit the Total as a workaround (see open points).

**G. Delete.** Delete an order → two confirmations → later order numbers close the gap → its payments go with it.

## 13. Not in this loop (do not build)

Printing, drafts, Customers pages, Airman orders (the Delivery screen has no Airman tab yet), Dashboard, Bangla, dark mode, install as an app, partial payments, removing a payment record, online payments, login, Branch, Export, staff pages, notifications.

## 14. Choices I made, to confirm

1. Upcoming to Deliver counts only from today forward. Orders already past their delivery date and not delivered are **not** counted. Say if you want overdue ones included.
2. Pay asks "Receive ৳X?" first, to prevent accidental taps.
3. A Pay record cannot be undone in this loop.
4. Saving is blocked if the money already received is more than the total.

## 15. Done checklist (test in this order)

1. Create three orders. All start as Pending. The tab counts are right.
2. Change one order to Cutting Slip – Done, then to Delivered. The status colours are right and the delivered date shows.
3. Change it back to Pending: the delivered date clears.
4. Set a delivery date within the upcoming days on one order. The Upcoming to Deliver card counts it. Tap the card: only that order shows. Clear the filter chip.
5. Change Upcoming delivery days in Settings to 0 or 10 and see the count change.
6. Open the Delivery screen. Search by BD number and tap Deliver. The row disappears and the order is Delivered.
7. A Delivered order with Due above 0 shows "Pay ৳X". The Due After Delivery card total matches. Tap the card: only owing orders show.
8. Press Pay, cancel the dialog: nothing changes. Press Pay again and confirm: Due is 0, the button disappears, the card total drops, and Order Details lists the payment with today’s date.
9. Edit that paid order, add an item worth ৳500: Due equals ৳500, Pay appears again, and the first payment record is still listed.
10. Edit the same order so the total is less than the money received: saving is blocked with the message.
11. Use tab + search + a card filter together. The results match all three.
12. Delete a paid order with both confirmation steps. Later order numbers close the gap and the Due After Delivery total changes.
13. Open the app on a second device: statuses, payments and settings match.
14. The word "optional" appears nowhere.
