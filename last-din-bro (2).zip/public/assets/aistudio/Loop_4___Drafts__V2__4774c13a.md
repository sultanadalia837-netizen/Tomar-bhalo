# Loop 4 — Drafts (V2)

Part of the Tailor Shop Manager PRD v1.0 · Build only this loop, on top of finished Loops 1 to 3 · Also read the App Map, and continue from the current app (section 0)

## 0. Continue from what exists (read first)

This loop continues one app. With this document you receive the **App Map** and the **current app** (design and code) as the last loop left it.

- Never create a second copy of a screen or component that already exists. Open the existing one and change it **in place**.
- Keep the existing navigation, layout, colours and wording. Do not restyle, rename or regenerate earlier work.
- Anything new must look like it was always part of the app. Reuse the existing cards, badges, buttons, forms, dialogs, tabs, and empty and loading states.
- Each item below is marked **EXISTING** (leave alone), **EXTEND** (change in place, exactly as listed) or **NEW** (create).
- If you cannot find an existing screen or component, stop and ask me. Do not recreate it.

**EXISTING (leave alone):** Orders screen, order cards, Order Details, Delivery, print pages, Settings, and the form's fields and saving rules.

**EXTEND (change in place):**
- **Navigation:** add a **Drafts** link before Settings, with a count badge.
- **New Order form:** add **Save as Draft**, the three-choice Cancel dialog, the "Draft saved locally" label and the "Continue where you left off?" prompt.
- **The same form** also opens a draft: add the small "Draft" label and the buttons Save Order, Update Draft, Delete Draft and Cancel. Hide the print buttons while a draft is open. Do not create a separate draft form.

**NEW:** the **Drafts** screen (a list of draft cards, built like the existing cards).

## 1. Purpose and rules for the builder

Loop 4 lets the owner stop in the middle of a new order and finish it later, like a draft on Instagram: saved, but not yet a real order. When a draft can be saved, found on any device, finished into a real order, or deleted, the loop is done.

**Rules**

- Build only what is written here, on top of Loops 1 to 3. Do not change earlier behaviour except where section 3 says so.
- If something is not in this document, leave it out and tell me what you left out. If something is unclear, ask.
- Officer orders only. Airman drafts come with Airman orders in a later loop.
- Never write the word "optional" anywhere in the screen text.

## 2. What is new in this loop

1. A **Save as Draft** button on the New Order form.
2. A **Drafts** screen.
3. A "leave the form" prompt and a **local autosave** on the device.

## 3. What changes from earlier loops

- The navigation gets a third link, **Drafts**, with a small number badge showing how many drafts exist.
- The New Order form gets a **Save as Draft** button beside Save Order.
- The Cancel button on a new order now asks what to do with unfinished work (section 6).
- Drafts never appear in the Orders list, the tabs, the summary cards or the Delivery screen.

## 4. What a draft is

- An unfinished Officer order stored on the **server**, so it shows on every device.
- It has **no order number**, takes no number from the sequence, and creates **no customer**.
- It stores everything typed so far: items, measurements, customer fields, dates, ribbon, money fields.
- Minimum to save a draft: a **BD number and at least one item**. Otherwise show: "A draft needs a BD number and at least one item."
- It stores the time it was last saved.
- Items in a draft keep the price they had when added. Price changes in Settings do not change a draft.

## 5. Drafts screen

- A list of draft cards, newest saved first.
- Each card: customer name (or just the BD number if no name yet), BD number, a short items summary (for example "Battle Uniform ×1, Uniform Pant ×2"), the Total so far, and "Saved 2 hours ago".
- Tapping a card opens the draft in the form. A delete icon on the card removes the draft after one confirmation: "Delete this draft?" with Cancel and Delete.
- Empty state: "No drafts. Unfinished orders you save will appear here."

## 6. Working with the form

### 6.1 Save as Draft

- Tap **Save as Draft** on a new order: the draft is saved, a message "Draft saved" shows, and the app goes to the Drafts screen.

### 6.2 Cancel on a new order with anything typed

Show a dialog with three choices: **Save as Draft**, **Discard**, **Keep editing**. If the minimum for a draft is not met, **Save as Draft** is greyed out with the hint from section 4. An empty form closes without asking.

### 6.3 Opening a draft

- The same form opens, filled in, with a small "Draft" label at the top.
- Buttons: **Save Order**, **Update Draft**, **Delete Draft**, **Cancel**.
- **Save Order** finishes it: all normal saving rules apply (name, BD number, at least one item), the order gets the next Officer order number, the customer is created or matched, the draft disappears, and the new order shows in Orders.
- **Update Draft** saves the changes and stays a draft.
- **Delete Draft** asks "Delete this draft?" once, then removes it.
- **Cancel** with unsaved changes uses the same three-choice dialog, where "Save as Draft" means Update Draft.
- The Print Invoice and Cutting Slip buttons are **hidden** while a draft is open. Finish the draft first.

### 6.4 Local autosave

- While typing on a new order or a draft, the form saves a copy **on this device** every few seconds and shows "Draft saved locally".
- If the page is closed or reloaded by accident, the next time New Order is opened the app asks: "Continue where you left off?" with **Continue** and **Start fresh**.
- The local copy is removed when the order is saved, a draft is saved, or the owner chooses Discard or Start fresh.
- Editing an already saved order does **not** use local autosave. It keeps the "Unsaved changes" label from Loop 1.

## 7. Data additions

- **Draft:** all form fields as typed, items with copied prices, last saved time. No order number.
- **Device only:** one local autosave copy for the form.

## 8. User flows

**A. Phone call interrupts.** New Order → enter BD number and two items → customer calls back → tap Cancel → Save as Draft → the order is in Drafts.

**B. Finish later, on another device.** Open the app on the shop computer → Drafts → tap the draft → add measurements → Save Order → the order gets the next number and appears in Orders.

**C. Accidental close.** Browser closes mid-form → reopen the app → New Order → "Continue where you left off?" → Continue → everything is back.

**D. Not needed any more.** Drafts → delete icon → confirm → gone.

**E. Update a draft.** Open a draft → change an item → Update Draft → stays in Drafts with a new saved time.

## 9. Not in this loop (do not build)

Drafts for saved orders (an existing order never turns back into a draft), Airman drafts, sharing a draft, Customers pages, Airman orders, Dashboard, Bangla, dark mode, install as an app, login, Branch, Export, staff pages, notifications.

## 10. Choices I made, to confirm

1. Deleting a draft asks once; deleting an order still asks twice.
2. Print buttons are hidden on a draft form.
3. The order date stays as typed in the draft when it is finished.
4. If two devices edit the same draft, the last save wins.
5. A draft has no expiry and no limit on how many exist.

## 11. Done checklist (test in this order)

1. On a new order, add only an item and tap Save as Draft: the message appears. Add a BD number and tap again: the draft is saved and the Drafts badge shows 1.
2. The Orders list and the order-number sequence are unchanged. No customer was created.
3. Drafts shows the draft with the right items, total and time.
4. Open the draft on a second device. It appears there too.
5. Open it, fill the missing name, tap **Save Order**: the order gets the next number, the draft is gone, the customer exists.
6. Create another draft, open it, change an item, tap **Update Draft**: it stays in Drafts with the new time.
7. On a new order, type something and tap Cancel: the three-choice dialog shows. Try each choice.
8. With no BD number or item, **Save as Draft** in that dialog is greyed out with the hint.
9. Type in a new order, close the browser tab, reopen, tap New Order: the "Continue where you left off?" question appears and Continue restores everything.
10. Delete a draft with one confirmation.
11. Print buttons are hidden while a draft is open.
12. The word "optional" appears nowhere.
