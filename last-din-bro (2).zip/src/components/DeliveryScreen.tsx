import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ArrowLeft, Search, Truck, Check, X, Phone, User, Calendar } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PolarisTabs } from './polaris/PolarisTabs.tsx';
import { PolarisBadge } from './polaris/PolarisBadge.tsx';

function getDeliveryDiffDays(deliveryDateStr: string | undefined, today: string) {
  if (!deliveryDateStr) return null;
  const dDate = new Date(deliveryDateStr).getTime();
  const tDate = new Date(today).getTime();
  return Math.round((dDate - tDate) / (1000 * 3600 * 24));
}

interface DeliveryScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const DeliveryScreen: React.FC<DeliveryScreenProps> = ({ onNavigate }) => {
  const { state } = useApp();

  const [activeTab, setActiveTab] = useState<'Officer' | 'Airman'>('Officer');
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState('');

  // Undelivered Officer Orders
  const undeliveredOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status !== 'Delivered');
  }, [state.officerOrders]);

  // Undelivered Airman Orders
  const undeliveredAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status !== 'Delivered');
  }, [state.airmanOrders]);

  const currentList = activeTab === 'Officer' ? undeliveredOfficerOrders : undeliveredAirmanOrders;

  const filteredOrders = useMemo(() => {
    if (!searchQuery.trim()) return currentList;
    const q = searchQuery.toLowerCase().trim();
    return currentList.filter((order) => {
      const name = (order.customerName || '').toLowerCase();
      const phone = (order.customerPhone || '').toLowerCase();
      const bd = order.customerBdNumber.toLowerCase();
      const num = String(order.orderNumber);
      return name.includes(q) || phone.includes(q) || bd.includes(q) || num.includes(q);
    });
  }, [currentList, searchQuery]);

  const handleDeliver = (orderNumber: number) => {
    onNavigate('order-details', {
      orderNumber,
      category: activeTab,
      fromDelivery: true,
    });
  };

  return (
    <PolarisPage
      title="Quick Delivery"
      subtitle="Quickly hand over ready orders and update delivery records"
      badge={
        <PolarisBadge tone={currentList.length > 0 ? 'warning' : 'success'}>
          {currentList.length} Pending
        </PolarisBadge>
      }
      backAction={() => onNavigate('orders')}
    >
      <div className="space-y-5">
        {/* Toast message */}
        {toastMessage && (
          <div className="p-3 bg-[#EAFBE7] border border-[#BBE5B3] text-[#108043] text-xs font-semibold rounded-lg flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-[#108043]" />
              <span>{toastMessage}</span>
            </div>
            <button onClick={() => setToastMessage('')} className="text-[#108043] hover:opacity-75">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        <PolarisCard flush>
          {/* Tabs & Search Header */}
          <div className="border-b border-[#E3E3E3]">
            <PolarisTabs<'Officer' | 'Airman'>
              tabs={[
                { id: 'Officer', label: 'Officer Orders', count: undeliveredOfficerOrders.length },
                { id: 'Airman', label: 'Airman Orders', count: undeliveredAirmanOrders.length },
              ]}
              selectedTab={activeTab}
              onSelectTab={(id: 'Officer' | 'Airman') => setActiveTab(id)}
            />
          </div>

          <div className="p-3 border-b border-[#E3E3E3] bg-[#FAFBFB] flex items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#616161]" />
              <input
                type="text"
                placeholder="Search by order #, BD number, customer name, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-[#D4D4D4] rounded-md text-[#303030] focus:outline-none focus:border-[#303030]"
              />
            </div>
            <div className="text-xs text-[#616161] font-medium">
              Showing {filteredOrders.length} order{filteredOrders.length === 1 ? '' : 's'}
            </div>
          </div>

          {/* Table (Queue Archetype from Section 8 & 18) */}
          {filteredOrders.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#e0e0e0] bg-[#f5f5f7] text-[#6e6e73] font-semibold h-[40px]">
                    <th className="px-4 py-2 w-24">Order #</th>
                    <th className="px-4 py-2 w-28">BD Number</th>
                    <th className="px-4 py-2">Customer</th>
                    <th className="px-4 py-2">Details / Items</th>
                    <th className="px-4 py-2 w-36">Delivery Due</th>
                    <th className="px-4 py-2 w-28">Status</th>
                    {activeTab === 'Officer' && <th className="px-4 py-2 text-right w-24">Due</th>}
                    <th className="px-4 py-2 text-right w-36">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f0f0f0]">
                  {filteredOrders.map((order: any) => {
                    const dueAmount = activeTab === 'Officer' ? Number(order.due) || 0 : 0;
                    const diffDays = getDeliveryDiffDays(order.deliveryDate, new Date().toISOString().slice(0, 10));
                    const isOverdue = diffDays !== null && diffDays < 0;
                    const isToday = diffDays === 0;
                    const isSoon = diffDays !== null && diffDays > 0 && diffDays <= 3;

                    return (
                      <tr
                        key={order.orderNumber}
                        onClick={() => handleDeliver(order.orderNumber)}
                        className="h-16 hover:bg-[#f0f0f0] transition-colors cursor-pointer"
                      >
                        <td className="px-4 py-3">
                          <span className="entity-chip">
                            #{order.orderNumber}
                          </span>
                        </td>
                        <td className="px-4 py-3 font-mono font-semibold text-[#1d1d1f] text-sm">
                          {order.customerBdNumber}
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-[#1d1d1f] text-sm">{order.customerName}</div>
                          {order.customerPhone && (
                            <div className="text-xs text-[#6e6e73] flex items-center space-x-1 mt-0.5">
                              <Phone className="w-3 h-3 inline" />
                              <span>{order.customerPhone}</span>
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3 text-[#1d1d1f] text-xs font-normal max-w-xs">
                          {activeTab === 'Officer' ? (
                            <span className="line-clamp-1">
                              {order.items?.map((i: any) => `${i.name} ×${i.quantity}`).join(', ') || 'No items'}
                            </span>
                          ) : (
                            <div className="flex items-center space-x-2">
                              <span className="font-semibold text-[#1d1d1f] line-clamp-1">
                                {order.items?.map((i: any) => `${i.name} (${i.ivNumber || 'No IV'})`).join(', ')}
                              </span>
                              <span className="text-xs text-[#6e6e73] font-mono">
                                • {order.runningYear}
                              </span>
                            </div>
                          )}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-1.5 font-mono text-xs font-semibold">
                            <span className="text-[#1d1d1f]">{order.deliveryDate || 'Not set'}</span>
                            {isOverdue && (
                              <span className="chip-negative text-[11px]">
                                Overdue
                              </span>
                            )}
                            {isToday && (
                              <span className="chip-ember text-[11px]">
                                Today!
                              </span>
                            )}
                            {isSoon && (
                              <span className="chip-ember text-[11px]">
                                {diffDays}d
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <PolarisBadge
                            tone={
                              order.status === 'Ready'
                                ? 'success'
                                : order.status === 'Processing'
                                ? 'info'
                                : 'neutral'
                            }
                          >
                            {order.status}
                          </PolarisBadge>
                        </td>
                        {activeTab === 'Officer' && (
                          <td className="px-4 py-3 text-right font-semibold tabular-nums font-mono text-sm">
                            {dueAmount > 0 ? (
                              <span className="text-[#c62828]">৳{dueAmount.toLocaleString()}</span>
                            ) : (
                              <span className="text-[#1e7b43] font-semibold">৳0</span>
                            )}
                          </td>
                        )}
                        <td className="px-4 py-3 text-right">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeliver(order.orderNumber);
                            }}
                            className="btn-primary h-8 px-4 text-xs font-semibold inline-flex items-center space-x-1.5 shadow-xs"
                          >
                            <Truck className="w-3.5 h-3.5" />
                            <span>Deliver</span>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-14 text-center text-[#6e6e73] text-sm">
              <Truck className="w-10 h-10 mx-auto mb-2 text-[#6e6e73] opacity-40" />
              <p className="font-semibold text-[#1d1d1f]">Nothing waiting for delivery</p>
              <p className="mt-1 text-xs text-[#6e6e73]">All {activeTab.toLowerCase()} orders have been handed over or match no search results.</p>
            </div>
          )}

          {/* Explanation Footnote (Section 4.3 in design.md) */}
          <div className="px-4 py-3 bg-[#f5f5f7] border-t border-[#e0e0e0] text-[12px] text-[#6e6e73] text-center">
            Handing over an order marks it Delivered. Invoices, pay records, and balance calculations stay completely intact.
          </div>
        </PolarisCard>
      </div>
    </PolarisPage>
  );
};
