import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { PWAInstallButton } from './PWAInstallButton.tsx';
import {
  Scissors,
  ClipboardList,
  Plane,
  Truck,
  FileText,
  Users,
  History,
  UserCheck,
  BarChart3,
  LayoutDashboard,
  Settings,
  Menu,
  X,
} from 'lucide-react';

export type ScreenName =
  | 'orders'
  | 'airman-orders'
  | 'delivery'
  | 'drafts'
  | 'customers'
  | 'customer-history'
  | 'staff-management'
  | 'staff-summary'
  | 'dashboard'
  | 'settings'
  | 'new-officer-order'
  | 'edit-officer-order'
  | 'new-airman-order'
  | 'edit-airman-order'
  | 'order-details'
  | 'worker-page'
  | 'worker-history'
  | 'print-slip'
  | 'print-invoice'
  | 'print-worker-statement'
  | 'confirm-delivery';

interface NavbarProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentScreen, onNavigate }) => {
  const { state } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const draftsCount = state.drafts.length;

  const navItems: { id: ScreenName; label: string; icon: React.ReactNode; badge?: number }[] = [
    { id: 'orders', label: 'Orders', icon: <ClipboardList className="w-4 h-4" /> },
    { id: 'airman-orders', label: 'Airman Orders', icon: <Plane className="w-4 h-4" /> },
    { id: 'delivery', label: 'Delivery', icon: <Truck className="w-4 h-4" /> },
    {
      id: 'drafts',
      label: 'Drafts',
      icon: <FileText className="w-4 h-4" />,
      badge: draftsCount > 0 ? draftsCount : undefined,
    },
    { id: 'customers', label: 'Customers', icon: <Users className="w-4 h-4" /> },
    { id: 'customer-history', label: 'Customer History', icon: <History className="w-4 h-4" /> },
    { id: 'staff-management', label: 'Staff Management', icon: <UserCheck className="w-4 h-4" /> },
    { id: 'staff-summary', label: 'Staff Summary', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
  ];

  const handleNav = (screen: ScreenName) => {
    onNavigate(screen);
    setMobileMenuOpen(false);
  };

  const isActive = (itemId: ScreenName) => {
    if (currentScreen === itemId) return true;
    if (itemId === 'orders' && (currentScreen === 'new-officer-order' || currentScreen === 'edit-officer-order')) return true;
    if (itemId === 'airman-orders' && (currentScreen === 'new-airman-order' || currentScreen === 'edit-airman-order')) return true;
    if (itemId === 'staff-management' && currentScreen === 'worker-page') return true;
    if (itemId === 'staff-summary' && currentScreen === 'worker-history') return true;
    return false;
  };

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-40 print:hidden shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div
            onClick={() => handleNav('orders')}
            className="flex items-center space-x-2.5 cursor-pointer hover:opacity-90 transition-opacity"
          >
            <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-xs">
              <Scissors className="w-5 h-5 transform -rotate-45" />
            </div>
            <div>
              <span className="font-bold text-gray-900 text-lg leading-tight block">
                {state.settings.invoiceShopName || 'Raymond'}
              </span>
              <span className="text-xs text-blue-600 font-medium tracking-wide block">BAF Outfitter</span>
            </div>
          </div>

          <div className="hidden xl:flex items-center space-x-2">
            <nav className="flex items-center space-x-1" aria-label="Main Navigation">
              {navItems.map((item) => {
                const active = isActive(item.id);
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNav(item.id)}
                    className={`relative flex items-center space-x-1.5 px-3 py-2 rounded-md text-xs font-medium transition-colors ${
                      active
                        ? 'bg-blue-50 text-blue-700 font-semibold shadow-xs'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                    {item.badge !== undefined && (
                      <span className="ml-1 px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-blue-600 text-white">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
            <PWAInstallButton variant="navbar" />
          </div>

          {/* Mobile Menu Button */}
          <div className="xl:hidden flex items-center space-x-2">
            <PWAInstallButton variant="navbar" />
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-gray-600 hover:text-gray-900 hover:bg-gray-100 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b border-gray-200 px-4 pt-2 pb-4 space-y-1">
          {navItems.map((item) => {
            const active = isActive(item.id);
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-sm font-medium ${
                  active ? 'bg-blue-50 text-blue-700 font-semibold' : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center space-x-3">
                  {item.icon}
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="px-2 py-0.5 text-xs font-bold rounded-full bg-blue-600 text-white">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      )}
    </header>
  );
};
