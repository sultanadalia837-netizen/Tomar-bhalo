import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface ToastItem {
  id: string;
  message: string;
  type?: ToastType;
  title?: string;
  duration?: number;
}

interface ToastContextType {
  showToast: (message: string, options?: { type?: ToastType; title?: string; duration?: number }) => void;
  success: (message: string, title?: string) => void;
  error: (message: string, title?: string) => void;
  info: (message: string, title?: string) => void;
  warning: (message: string, title?: string) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const showToast = useCallback(
    (message: string, options?: { type?: ToastType; title?: string; duration?: number }) => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
      const type = options?.type || 'success';
      const title = options?.title;
      const duration = options?.duration ?? 4000;

      const newToast: ToastItem = {
        id,
        message,
        type,
        title,
        duration,
      };

      setToasts((prev) => [...prev.slice(-3), newToast]); // keep max 4 toasts
    },
    []
  );

  const success = useCallback((message: string, title?: string) => {
    showToast(message, { type: 'success', title });
  }, [showToast]);

  const error = useCallback((message: string, title?: string) => {
    showToast(message, { type: 'error', title });
  }, [showToast]);

  const info = useCallback((message: string, title?: string) => {
    showToast(message, { type: 'info', title });
  }, [showToast]);

  const warning = useCallback((message: string, title?: string) => {
    showToast(message, { type: 'warning', title });
  }, [showToast]);

  return (
    <ToastContext.Provider value={{ showToast, success, error, info, warning }}>
      {children}

      {/* Floating Toast Container */}
      <div
        aria-live="polite"
        className="fixed top-4 right-4 sm:top-5 sm:right-5 z-[9999] flex flex-col items-end gap-2.5 pointer-events-none max-w-sm w-full px-3 sm:px-0"
      >
        <AnimatePresence>
          {toasts.map((toast) => (
            <ToastCard key={toast.id} toast={toast} onDismiss={() => removeToast(toast.id)} />
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
};

const ToastCard: React.FC<{ toast: ToastItem; onDismiss: () => void }> = ({ toast, onDismiss }) => {
  const duration = toast.duration ?? 4000;

  useEffect(() => {
    if (duration <= 0) return;
    const timer = setTimeout(() => {
      onDismiss();
    }, duration);
    return () => clearTimeout(timer);
  }, [duration, onDismiss]);

  const isSuccess = toast.type === 'success' || !toast.type;
  const isError = toast.type === 'error';
  const isWarning = toast.type === 'warning';
  const isInfo = toast.type === 'info';

  const icon = isSuccess ? (
    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" strokeWidth={2.4} />
  ) : isError ? (
    <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" strokeWidth={2.4} />
  ) : isWarning ? (
    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" strokeWidth={2.4} />
  ) : (
    <Info className="w-4 h-4 text-sky-500 shrink-0" strokeWidth={2.4} />
  );

  const borderStyle = isSuccess
    ? 'border-emerald-200/90'
    : isError
    ? 'border-rose-200/90'
    : isWarning
    ? 'border-amber-200/90'
    : 'border-sky-200/90';

  return (
    <motion.div
      initial={{ opacity: 0, y: -16, scale: 0.94 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.92, y: -10 }}
      transition={{ type: 'spring', damping: 25, stiffness: 350 }}
      className={`pointer-events-auto relative w-full overflow-hidden rounded-2xl bg-white/95 backdrop-blur-md p-3.5 sm:p-4 text-gray-900 border ${borderStyle} shadow-[0_12px_32px_-6px_rgba(0,0,0,0.14),0_2px_8px_rgba(0,0,0,0.06)]`}
    >
      <div className="flex items-start gap-3">
        <div className="mt-0.5 p-1 rounded-lg bg-gray-50 shrink-0">{icon}</div>

        <div className="flex-1 min-w-0 pr-1">
          {toast.title && (
            <h4 className="text-xs font-bold text-gray-950 tracking-tight leading-snug">
              {toast.title}
            </h4>
          )}
          <p className="text-xs font-medium text-gray-700 leading-relaxed mt-0.5 break-words">
            {toast.message}
          </p>
        </div>

        {/* Manual Dismiss Cross Button */}
        <button
          type="button"
          onClick={onDismiss}
          className="p-1.5 rounded-lg text-gray-400 hover:text-gray-900 hover:bg-gray-100 transition-colors shrink-0 cursor-pointer active:scale-90"
          aria-label="Dismiss notification"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Subtle Progress Bar */}
      {duration > 0 && (
        <motion.div
          initial={{ width: '100%' }}
          animate={{ width: '0%' }}
          transition={{ duration: duration / 1000, ease: 'linear' }}
          className={`absolute bottom-0 left-0 h-[2.5px] ${
            isSuccess
              ? 'bg-emerald-500'
              : isError
              ? 'bg-rose-500'
              : isWarning
              ? 'bg-amber-500'
              : 'bg-sky-500'
          }`}
        />
      )}
    </motion.div>
  );
};

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) {
    // Return fallback in case used outside provider
    return {
      showToast: (msg: string) => console.log('Toast:', msg),
      success: (msg: string) => console.log('Success:', msg),
      error: (msg: string) => console.error('Error:', msg),
      info: (msg: string) => console.log('Info:', msg),
      warning: (msg: string) => console.warn('Warning:', msg),
    };
  }
  return context;
}
