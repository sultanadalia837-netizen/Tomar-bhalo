import React from 'react';

interface ChartCursorProps {
  visible: boolean;
  x: number;
  y: number;
  title: string;
  value: string | number;
  secondary?: string;
  badge?: string;
}

export const ChartCursor: React.FC<ChartCursorProps> = ({
  visible,
  x,
  y,
  title,
  value,
  secondary,
  badge,
}) => {
  if (!visible) return null;

  return (
    <div
      className="pointer-events-none fixed z-50 transform -translate-x-1/2 -translate-y-full mb-3 transition-transform duration-75 ease-out select-none"
      style={{ left: `${x}px`, top: `${y}px` }}
    >
      <div className="bg-[#0a0d12]/95 backdrop-blur-md text-white px-3.5 py-2 rounded-2xl shadow-[0_12px_28px_rgba(0,0,0,0.25)] border border-white/10 text-xs min-w-[130px]">
        <div className="flex items-center justify-between gap-2 mb-0.5">
          <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">
            {title}
          </span>
          {badge && (
            <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-[#0069e0] text-white">
              {badge}
            </span>
          )}
        </div>
        <div className="text-sm font-bold text-white tabular-nums tracking-tight">
          {value}
        </div>
        {secondary && (
          <div className="text-[10px] text-gray-300 mt-0.5 border-t border-white/10 pt-1">
            {secondary}
          </div>
        )}
      </div>

      {/* Downward triangle pointer */}
      <div className="w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-[#0a0d12] mx-auto" />
    </div>
  );
};
