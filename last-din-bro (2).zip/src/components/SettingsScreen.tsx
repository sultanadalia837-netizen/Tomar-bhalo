import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { PWAInstallButton } from './PWAInstallButton.tsx';
import { SlipType } from '../types/index.ts';
import {
  Settings,
  Scissors,
  Store,
  Clock,
  ShieldCheck,
  Save,
  Download,
  CheckCircle2,
  Plus,
  Trash2,
  Edit2,
  List,
  Shirt,
} from 'lucide-react';

export const SettingsScreen: React.FC = () => {
  const {
    state,
    updateSettings,
    resetToFreshState,
    addOfficerItem,
    updateOfficerItem,
    deleteOfficerItem,
    addAirmanItem,
    updateAirmanItem,
    deleteAirmanItem,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'general' | 'officer-items' | 'airman-items' | 'lists'>('general');

  // General settings state
  const [shopName, setShopName] = useState(state.settings.invoiceShopName || 'Raymond');
  const [phone, setPhone] = useState(state.settings.invoiceShopPhone || '01711-000000');
  const [address, setAddress] = useState(
    state.settings.invoiceShopAddress || 'BAF Base Tailor Market, Dhaka Cantonment'
  );
  const [upcomingDays, setUpcomingDays] = useState(
    state.settings.upcomingDeliveryDays || 3
  );
  const [savedToast, setSavedToast] = useState(false);

  // Officer items form
  const [newOfficerName, setNewOfficerName] = useState('');
  const [newOfficerPrice, setNewOfficerPrice] = useState('');
  const [newOfficerSlipType, setNewOfficerSlipType] = useState<SlipType>('Shirt');
  const [editingOfficerId, setEditingOfficerId] = useState<string | null>(null);
  const [editOfficerName, setEditOfficerName] = useState('');
  const [editOfficerPrice, setEditOfficerPrice] = useState('');
  const [editOfficerSlipType, setEditOfficerSlipType] = useState<SlipType>('Shirt');

  // Airman items form
  const [newAirmanName, setNewAirmanName] = useState('');
  const [newAirmanSlipType, setNewAirmanSlipType] = useState<SlipType>('Shirt');
  const [editingAirmanId, setEditingAirmanId] = useState<string | null>(null);
  const [editAirmanName, setEditAirmanName] = useState('');
  const [editAirmanSlipType, setEditAirmanSlipType] = useState<SlipType>('Shirt');

  // Lists form
  const [newRibbon, setNewRibbon] = useState('');
  const [newBranch, setNewBranch] = useState('');
  const [newRunningYear, setNewRunningYear] = useState('');

  const handleSaveGeneral = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      invoiceShopName: shopName,
      invoiceShopPhone: phone,
      invoiceShopAddress: address,
      upcomingDeliveryDays: Number(upcomingDays),
    });
    setSavedToast(true);
    setTimeout(() => setSavedToast(false), 3000);
  };

  const handleExportData = () => {
    const dataStr = JSON.stringify(state, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `raymond-tailor-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Officer item actions
  const handleAddOfficerItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOfficerName.trim()) return;
    const res = addOfficerItem(newOfficerName.trim(), Number(newOfficerPrice) || 0, 'Uniform', newOfficerSlipType);
    if (res.success) {
      setNewOfficerName('');
      setNewOfficerPrice('');
      setNewOfficerSlipType('Shirt');
    } else {
      alert(res.error || 'Failed to add item');
    }
  };

  const startEditOfficer = (item: any) => {
    setEditingOfficerId(item.id);
    setEditOfficerName(item.name);
    setEditOfficerPrice(String(item.price || 0));
    setEditOfficerSlipType(item.slipType || 'Shirt');
  };

  const handleSaveEditOfficer = () => {
    if (!editingOfficerId || !editOfficerName.trim()) return;
    const res = updateOfficerItem(
      editingOfficerId,
      editOfficerName.trim(),
      Number(editOfficerPrice) || 0,
      'Uniform',
      editOfficerSlipType
    );
    if (res.success) {
      setEditingOfficerId(null);
    } else {
      alert(res.error || 'Failed to update item');
    }
  };

  // Airman item actions
  const handleAddAirmanItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAirmanName.trim()) return;
    const res = addAirmanItem(newAirmanName.trim(), newAirmanSlipType);
    if (res.success) {
      setNewAirmanName('');
      setNewAirmanSlipType('Shirt');
    } else {
      alert(res.error || 'Failed to add item');
    }
  };

  const startEditAirman = (item: any) => {
    setEditingAirmanId(item.id);
    setEditAirmanName(item.name);
    setEditAirmanSlipType(item.slipType || 'Shirt');
  };

  const handleSaveEditAirman = () => {
    if (!editingAirmanId || !editAirmanName.trim()) return;
    const res = updateAirmanItem(editingAirmanId, editAirmanName.trim(), editAirmanSlipType);
    if (res.success) {
      setEditingAirmanId(null);
    } else {
      alert(res.error || 'Failed to update item');
    }
  };

  // Lists actions
  const handleAddRibbon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRibbon.trim()) return;
    const val = newRibbon.trim();
    if (state.settings.ribbonValues.includes(val)) return;
    updateSettings({ ribbonValues: [...state.settings.ribbonValues, val] });
    setNewRibbon('');
  };

  const handleDeleteRibbon = (val: string) => {
    updateSettings({ ribbonValues: state.settings.ribbonValues.filter((r) => r !== val) });
  };

  const handleAddBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBranch.trim()) return;
    const val = newBranch.trim();
    if (state.settings.branchValues.includes(val)) return;
    updateSettings({ branchValues: [...state.settings.branchValues, val] });
    setNewBranch('');
  };

  const handleDeleteBranch = (val: string) => {
    updateSettings({ branchValues: state.settings.branchValues.filter((b) => b !== val) });
  };

  const handleAddRunningYear = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRunningYear.trim()) return;
    const val = newRunningYear.trim();
    if (state.settings.runningYears.includes(val)) return;
    updateSettings({ runningYears: [...state.settings.runningYears, val].sort() });
    setNewRunningYear('');
  };

  const handleDeleteRunningYear = (val: string) => {
    updateSettings({ runningYears: state.settings.runningYears.filter((y) => y !== val) });
  };

  return (
    <PolarisPage
      title="Tailor Workshop Settings"
      subtitle="Configure shop branding, item catalog slip types, lists, and data backup"
    >
      {/* Settings Navigation Tabs */}
      <div className="flex border-b border-[#E3E3E3] mb-6 overflow-x-auto space-x-1">
        {[
          { id: 'general', label: 'General & Profile', icon: <Settings className="w-4 h-4" /> },
          { id: 'officer-items', label: 'Officer Items', icon: <Shirt className="w-4 h-4" /> },
          { id: 'airman-items', label: 'Airman Items', icon: <Scissors className="w-4 h-4" /> },
          { id: 'lists', label: 'Lists & Options', icon: <List className="w-4 h-4" /> },
        ].map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center space-x-2 py-2.5 px-4 text-xs font-[600] border-b-2 transition-colors cursor-pointer whitespace-nowrap ${
              activeTab === tab.id
                ? 'border-[#005BD3] text-[#005BD3]'
                : 'border-transparent text-[#616161] hover:text-[#1A1A1A]'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {savedToast && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-900 flex items-center gap-2.5 mb-6 animate-in fade-in duration-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span className="text-sm font-semibold">Settings successfully updated!</span>
        </div>
      )}

      {/* ================= TAB: GENERAL ================= */}
      {activeTab === 'general' && (
        <form onSubmit={handleSaveGeneral} className="space-y-6">
          <PolarisCard
            title="Tailor Studio Profile"
            subtitle="Branding used across officer cutting slips and delivery receipts"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
                  Shop / Studio Name
                </label>
                <input
                  type="text"
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-sm text-[#0a0d12] font-medium focus:bg-white focus:outline-none focus:border-[#0069e0]"
                  placeholder="e.g. Raymond"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
                  Contact Phone
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-sm text-[#0a0d12] font-medium focus:bg-white focus:outline-none focus:border-[#0069e0]"
                  placeholder="e.g. 01711-xxxxxx"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
                  Workshop Location / Cantonment Address
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-sm text-[#0a0d12] font-medium focus:bg-white focus:outline-none focus:border-[#0069e0]"
                  placeholder="BAF Base Tailor Market, Dhaka"
                />
              </div>
            </div>
          </PolarisCard>

          <PolarisCard
            title="Delivery Thresholds"
            subtitle="Configure upcoming delivery reminders and workshop velocity triggers"
          >
            <div className="max-w-md">
              <label className="block text-xs font-semibold text-[#0a0d12] mb-1.5">
                Upcoming Delivery Warning Horizon (Days)
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="1"
                  max="14"
                  value={upcomingDays}
                  onChange={(e) => setUpcomingDays(Number(e.target.value))}
                  className="w-24 h-10 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-sm text-[#0a0d12] font-semibold text-center focus:bg-white focus:outline-none focus:border-[#0069e0]"
                />
                <span className="text-xs text-[#535862]">
                  Orders with delivery dates within this window trigger alert tags
                </span>
              </div>
            </div>
          </PolarisCard>

          <PolarisCard
            title="Cloud Database & Security"
            subtitle="Persistent database with offline-first caching"
          >
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-[#FAFAFA] border border-[#E3E3E3]">
                  <span className="text-[11px] font-semibold text-[#616161] block">Cloud Database</span>
                  <span className="text-xs font-bold text-[#1A1A1A] flex items-center gap-1.5 mt-0.5">
                    <span className="w-2 h-2 rounded-full bg-[#008060]" />
                    Firestore Active
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-[#FAFAFA] border border-[#E3E3E3]">
                  <span className="text-[11px] font-semibold text-[#616161] block">Security Rules</span>
                  <span className="text-xs font-bold text-[#1A1A1A] flex items-center gap-1.5 mt-0.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#2563EB]" />
                    ABAC Guard Deployed
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-[#FAFAFA] border border-[#E3E3E3]">
                  <span className="text-[11px] font-semibold text-[#616161] block">Offline Support</span>
                  <span className="text-xs font-bold text-[#1A1A1A] flex items-center gap-1.5 mt-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#008060]" />
                    IndexedDB Cache
                  </span>
                </div>
              </div>
            </div>
          </PolarisCard>

          <PolarisCard
            title="Progressive Web App (PWA)"
            subtitle="Install Raymond as a standalone app on Mobile or Desktop"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <p className="text-xs text-[#616161]">
                Launch from your home screen with zero browser bars and offline support.
              </p>
              <PWAInstallButton variant="settings" />
            </div>
          </PolarisCard>

          <PolarisCard
            title="Backup & Fresh Workspace Reset"
            subtitle="Safeguard order history or reset local data to a clean fresh slate"
          >
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={handleExportData}
                className="px-4 py-2 rounded-lg bg-[#FAFAFA] hover:bg-[#F3F3F3] text-[#1A1A1A] border border-[#D8D8D8] text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-xs"
              >
                <Download className="w-4 h-4 text-[#2563EB]" />
                <span>Export Full Studio Backup (JSON)</span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  if (window.confirm('Are you sure you want to reset all data to a clean fresh state?')) {
                    await resetToFreshState();
                    alert('Studio reset to a clean, fresh state successfully!');
                  }
                }}
                className="px-4 py-2 rounded-lg bg-white hover:bg-rose-50 text-[#8E0B21] border border-[#FCA5A5] text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-xs ml-auto"
              >
                <span>Reset to Clean Fresh Workspace</span>
              </button>
            </div>
          </PolarisCard>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-6 py-2 rounded-lg bg-[#1A1A1A] hover:bg-black text-white text-xs font-semibold shadow-xs flex items-center gap-2 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Save Workshop Settings</span>
            </button>
          </div>
        </form>
      )}

      {/* ================= TAB: OFFICER ITEMS ================= */}
      {activeTab === 'officer-items' && (
        <div className="space-y-6">
          <PolarisCard
            title="Add New Officer Item"
            subtitle="Configure catalog items with default pricing and cutting slip type"
          >
            <form onSubmit={handleAddOfficerItem} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1">Item Name</label>
                <input
                  type="text"
                  value={newOfficerName}
                  onChange={(e) => setNewOfficerName(e.target.value)}
                  placeholder="e.g. Safari Suit, Meskit"
                  className="w-full h-9 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-xs text-[#0a0d12] focus:bg-white focus:outline-none focus:border-[#0069e0]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1">Price (৳)</label>
                <input
                  type="number"
                  min="0"
                  value={newOfficerPrice}
                  onChange={(e) => setNewOfficerPrice(e.target.value)}
                  placeholder="0"
                  className="w-full h-9 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-xs text-[#0a0d12] focus:bg-white focus:outline-none focus:border-[#0069e0]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1">Slip Type</label>
                <select
                  value={newOfficerSlipType}
                  onChange={(e) => setNewOfficerSlipType(e.target.value as SlipType)}
                  className="w-full h-9 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-xs text-[#0a0d12] focus:bg-white focus:outline-none focus:border-[#0069e0]"
                >
                  <option value="Shirt">Shirt</option>
                  <option value="Pant">Pant</option>
                  <option value="Shirt + Pant">Shirt + Pant</option>
                </select>
              </div>
              <div className="sm:col-span-4 flex justify-end">
                <button
                  type="submit"
                  className="h-8 px-4 rounded-lg bg-[#005BD3] hover:bg-[#004bb5] text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Officer Item</span>
                </button>
              </div>
            </form>
          </PolarisCard>

          <PolarisCard title={`Officer Items Catalog (${state.settings.items.length})`} flush={true}>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="h-9 bg-[#FAFAFA] border-b border-[#E3E3E3] text-[11px] font-[550] text-[#616161]">
                    <th className="px-4 py-2">Item Name</th>
                    <th className="px-4 py-2 text-right">Default Price</th>
                    <th className="px-4 py-2 text-center">Slip Type</th>
                    <th className="px-4 py-2 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3E3]">
                  {state.settings.items.map((item) => (
                    <tr key={item.id} className="h-11 hover:bg-[#F9FAFB]">
                      {editingOfficerId === item.id ? (
                        <>
                          <td className="px-4 py-2">
                            <input
                              type="text"
                              value={editOfficerName}
                              onChange={(e) => setEditOfficerName(e.target.value)}
                              className="h-7 px-2 w-full rounded border border-[#005BD3] text-xs"
                            />
                          </td>
                          <td className="px-4 py-2 text-right">
                            <input
                              type="number"
                              min="0"
                              value={editOfficerPrice}
                              onChange={(e) => setEditOfficerPrice(e.target.value)}
                              className="h-7 px-2 w-24 text-right rounded border border-[#005BD3] text-xs ml-auto"
                            />
                          </td>
                          <td className="px-4 py-2 text-center">
                            <select
                              value={editOfficerSlipType}
                              onChange={(e) => setEditOfficerSlipType(e.target.value as SlipType)}
                              className="h-7 px-2 rounded border border-[#005BD3] text-xs"
                            >
                              <option value="Shirt">Shirt</option>
                              <option value="Pant">Pant</option>
                              <option value="Shirt + Pant">Shirt + Pant</option>
                            </select>
                          </td>
                          <td className="px-4 py-2 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={handleSaveEditOfficer}
                              className="h-7 px-2.5 rounded bg-[#005BD3] text-white text-[11px] font-semibold"
                            >
                              Save
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingOfficerId(null)}
                              className="h-7 px-2 rounded border border-[#E3E3E3] text-[#616161] text-[11px]"
                            >
                              Cancel
                            </button>
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="px-4 py-2 font-[600] text-[#1A1A1A]">{item.name}</td>
                          <td className="px-4 py-2 text-right tabular-nums text-[#303030]">৳{item.price}</td>
                          <td className="px-4 py-2 text-center">
                            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#EAF4FF] text-[#005BD3]">
                              {item.slipType || 'Shirt'}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => startEditOfficer(item)}
                              className="p-1 rounded text-[#616161] hover:text-[#005BD3] cursor-pointer"
                              title="Edit item"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteOfficerItem(item.id)}
                              className="p-1 rounded text-[#616161] hover:text-[#8E0B21] cursor-pointer"
                              title="Delete item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </PolarisCard>
        </div>
      )}

      {/* ================= TAB: AIRMAN ITEMS ================= */}
      {activeTab === 'airman-items' && (
        <div className="space-y-6">
          <PolarisCard
            title="Add New Airman Item"
            subtitle="Configure airman items with cutting slip type"
          >
            <form onSubmit={handleAddAirmanItem} className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1">Item Name</label>
                <input
                  type="text"
                  value={newAirmanName}
                  onChange={(e) => setNewAirmanName(e.target.value)}
                  placeholder="e.g. Combat Shirt, Service Pant"
                  className="w-full h-9 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-xs text-[#0a0d12] focus:bg-white focus:outline-none focus:border-[#0069e0]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#0a0d12] mb-1">Slip Type</label>
                <select
                  value={newAirmanSlipType}
                  onChange={(e) => setNewAirmanSlipType(e.target.value as SlipType)}
                  className="w-full h-9 px-3 rounded-lg bg-[#f6f7f8] border border-[#dbeafe] text-xs text-[#0a0d12] focus:bg-white focus:outline-none focus:border-[#0069e0]"
                >
                  <option value="Shirt">Shirt</option>
                  <option value="Pant">Pant</option>
                  <option value="Shirt + Pant">Shirt + Pant</option>
                </select>
              </div>
              <div className="sm:col-span-3 flex justify-end">
                <button
                  type="submit"
                  className="h-8 px-4 rounded-lg bg-[#5B3DF5] hover:bg-[#4b2fe0] text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Airman Item</span>
                </button>
              </div>
            </form>
          </PolarisCard>

          <PolarisCard title={`Airman Items List (${state.settings.airmanItems.length})`} flush={true}>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="h-9 bg-[#FAFAFA] border-b border-[#E3E3E3] text-[11px] font-[550] text-[#616161]">
                    <th className="px-4 py-2">Item Name</th>
                    <th className="px-4 py-2 text-center">Slip Type</th>
                    <th className="px-4 py-2 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#E3E3E3]">
                  {state.settings.airmanItems.map((item) => (
                    <tr key={item.id} className="h-11 hover:bg-[#F9FAFB]">
                      {editingAirmanId === item.id ? (
                        <>
                          <td className="px-4 py-2">
                            <input
                              type="text"
                              value={editAirmanName}
                              onChange={(e) => setEditAirmanName(e.target.value)}
                              className="h-7 px-2 w-full rounded border border-[#5B3DF5] text-xs"
                            />
                          </td>
                          <td className="px-4 py-2 text-center">
                            <select
                              value={editAirmanSlipType}
                              onChange={(e) => setEditAirmanSlipType(e.target.value as SlipType)}
                              className="h-7 px-2 rounded border border-[#5B3DF5] text-xs"
                            >
                              <option value="Shirt">Shirt</option>
                              <option value="Pant">Pant</option>
                              <option value="Shirt + Pant">Shirt + Pant</option>
                            </select>
                          </td>
                          <td className="px-4 py-2 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={handleSaveEditAirman}
                              className="h-7 px-2.5 rounded bg-[#5B3DF5] text-white text-[11px] font-semibold"
                            >
                              Save
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingAirmanId(null)}
                              className="h-7 px-2 rounded border border-[#E3E3E3] text-[#616161] text-[11px]"
                            >
                              Cancel
                            </button>
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="px-4 py-2 font-[600] text-[#1A1A1A]">{item.name}</td>
                          <td className="px-4 py-2 text-center">
                            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#F0EEFF] text-[#5B3DF5]">
                              {item.slipType || 'Shirt'}
                            </span>
                          </td>
                          <td className="px-4 py-2 text-right space-x-1.5 whitespace-nowrap">
                            <button
                              type="button"
                              onClick={() => startEditAirman(item)}
                              className="p-1 rounded text-[#616161] hover:text-[#5B3DF5] cursor-pointer"
                              title="Edit item"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteAirmanItem(item.id)}
                              className="p-1 rounded text-[#616161] hover:text-[#8E0B21] cursor-pointer"
                              title="Delete item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </PolarisCard>
        </div>
      )}

      {/* ================= TAB: LISTS (NO TRADE, NO OFFICE per FIX-19) ================= */}
      {activeTab === 'lists' && (
        <div className="space-y-6">
          {/* Ribbons */}
          <PolarisCard
            title={`Ribbon Values (${state.settings.ribbonValues.length})`}
            subtitle="Ribbon presets selectable during order creation"
          >
            <form onSubmit={handleAddRibbon} className="flex gap-2 mb-4">
              <input
                type="text"
                value={newRibbon}
                onChange={(e) => setNewRibbon(e.target.value)}
                placeholder="New ribbon (e.g. 1, 2, 3)"
                className="h-8 px-3 rounded-lg border border-[#E3E3E3] text-xs flex-1 max-w-xs"
              />
              <button
                type="submit"
                className="h-8 px-3 rounded-lg bg-[#303030] hover:bg-black text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Add Ribbon</span>
              </button>
            </form>
            <div className="flex flex-wrap gap-2">
              {state.settings.ribbonValues.map((ribbon) => (
                <span
                  key={ribbon}
                  className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-md bg-[#F4F4F4] text-[#1A1A1A] text-xs font-semibold border border-[#E3E3E3]"
                >
                  <span>{ribbon}</span>
                  <button
                    type="button"
                    onClick={() => handleDeleteRibbon(ribbon)}
                    className="text-[#616161] hover:text-[#8E0B21] cursor-pointer"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </PolarisCard>

          {/* Branches (Officer) */}
          <PolarisCard
            title={`Branch Values (${state.settings.branchValues.length})`}
            subtitle="Officer branches available on order forms and cutting slip headers"
          >
            <form onSubmit={handleAddBranch} className="flex gap-2 mb-4">
              <input
                type="text"
                value={newBranch}
                onChange={(e) => setNewBranch(e.target.value)}
                placeholder="New branch (e.g. GDP, AD, ENGG)"
                className="h-8 px-3 rounded-lg border border-[#E3E3E3] text-xs flex-1 max-w-xs"
              />
              <button
                type="submit"
                className="h-8 px-3 rounded-lg bg-[#005BD3] hover:bg-[#004bb5] text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Add Branch</span>
              </button>
            </form>
            <div className="flex flex-wrap gap-2">
              {state.settings.branchValues.map((branch) => (
                <span
                  key={branch}
                  className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-md bg-[#EAF4FF] text-[#005BD3] text-xs font-semibold border border-[#B4D7FF]"
                >
                  <span>{branch}</span>
                  <button
                    type="button"
                    onClick={() => handleDeleteBranch(branch)}
                    className="text-[#005BD3] hover:text-[#8E0B21] cursor-pointer"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </PolarisCard>

          {/* Running Years */}
          <PolarisCard
            title={`Running Years (${state.settings.runningYears.length})`}
            subtitle="Airman running years available on order forms"
          >
            <form onSubmit={handleAddRunningYear} className="flex gap-2 mb-4">
              <input
                type="text"
                value={newRunningYear}
                onChange={(e) => setNewRunningYear(e.target.value)}
                placeholder="New running year (e.g. 2026-2027)"
                className="h-8 px-3 rounded-lg border border-[#E3E3E3] text-xs flex-1 max-w-xs"
              />
              <button
                type="submit"
                className="h-8 px-3 rounded-lg bg-[#303030] hover:bg-black text-white text-xs font-semibold flex items-center space-x-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Add Running Year</span>
              </button>
            </form>
            <div className="flex flex-wrap gap-2">
              {state.settings.runningYears.map((year) => (
                <span
                  key={year}
                  className="inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-md bg-[#F4F4F4] text-[#1A1A1A] text-xs font-semibold border border-[#E3E3E3]"
                >
                  <span>{year}</span>
                  <button
                    type="button"
                    onClick={() => handleDeleteRunningYear(year)}
                    className="text-[#616161] hover:text-[#8E0B21] cursor-pointer"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          </PolarisCard>
        </div>
      )}
    </PolarisPage>
  );
};
