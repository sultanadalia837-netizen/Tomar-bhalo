import React, { useMemo, useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { useToast } from './elements/ToastNotification.tsx';
import {
  calculateWorkerMonthHishab,
  formatDate,
  getItemSlipType,
  formatShirtMeasurementsSlip,
  formatPantMeasurementsSlip,
} from '../utils/logic.ts';
import {
  exportCustomerInvoicePDF,
  exportShopRecordInvoicePDF,
} from '../utils/pdfGenerator.ts';
import { Printer, ArrowLeft, Scissors, FileText, Download, Building2, UserCheck, Phone } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface PrintPreviewScreenProps {
  type: 'slip' | 'invoice' | 'worker-statement';
  orderNumber?: number;
  category?: 'Officer' | 'Airman';
  workerId?: string;
  month?: string;
  itemIndex?: number;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const PrintPreviewScreen: React.FC<PrintPreviewScreenProps> = ({
  type,
  orderNumber,
  category = 'Officer',
  workerId,
  month,
  itemIndex,
  onNavigate,
}) => {
  const { state } = useApp();
  const toast = useToast();
  const [invoiceVariant, setInvoiceVariant] = useState<'customer' | 'shop'>('customer');

  const isOfficer = category === 'Officer';
  const officerOrder = isOfficer ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const airmanOrder = !isOfficer ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;
  const order = isOfficer ? officerOrder : airmanOrder;

  const worker = workerId ? state.workers.find((w) => w.id === workerId) : null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadInvoicePDF = () => {
    if (!officerOrder) return;
    if (invoiceVariant === 'customer') {
      exportCustomerInvoicePDF(officerOrder, state.settings);
      toast.success(`Customer Delivery Invoice #${officerOrder.orderNumber} downloaded as PDF!`);
    } else {
      exportShopRecordInvoicePDF(officerOrder, state.settings);
      toast.success(`Shop Record Invoice #${officerOrder.orderNumber} downloaded as PDF!`);
    }
  };

  const paperSize =
    type === 'invoice'
      ? state.settings.invoicePaperSize
      : state.settings.cuttingSlipPaperSize;

  const slipCards = useMemo(() => {
    if (!order) return [];
    const itemsToProcess =
      itemIndex !== undefined && order.items[itemIndex]
        ? [{ item: order.items[itemIndex], originalIndex: itemIndex }]
        : order.items.map((item, idx) => ({ item, originalIndex: idx }));

    const cards: Array<{
      key: string;
      headerTitle: string;
      ribbonText: string;
      branchText?: string;
      itemNameText: string;
      measurementsText: string;
      notesText?: string;
      partName: 'Shirt' | 'Pant';
      dateText: string;
    }> = [];

    const customerDisplay = isOfficer
      ? officerOrder?.customerName || `Officer ${order.customerBdNumber}`
      : airmanOrder?.customerName || `Airman ${order.customerBdNumber}`;

    const headerTitle = `#${order.orderNumber} ~ ${customerDisplay} ~ ${order.customerBdNumber}`;
    const ribbonText = order.ribbon ? `R - ${order.ribbon}` : '';
    const branchText = isOfficer && officerOrder?.branch ? officerOrder.branch : undefined;
    const dateText = isOfficer
      ? `Delivery: ${officerOrder?.deliveryDate || '—'}`
      : `Order: ${order.orderDate}`;

    itemsToProcess.forEach(({ item, originalIndex }) => {
      const catalogItem = isOfficer
        ? state.settings.items.find((i) => i.name.toLowerCase() === item.name.toLowerCase())
        : state.settings.airmanItems.find((i) => i.name.toLowerCase() === item.name.toLowerCase());
      const explicitType = (item as any).slipType || catalogItem?.slipType;
      const resolvedType = getItemSlipType(item.name, explicitType);

      const qty = item.quantity || 1;
      const qtySuffix = qty > 1 ? ` (Qty ${qty})` : '';
      const ivSuffix = !isOfficer && (item as any).ivNumber ? ` ~ IV: ${(item as any).ivNumber}` : '';

      const shirtNotes = [
        order.shirtMeasurements?.handWrittenNotes,
        order.shirtMeasurements?.extraNotes,
      ]
        .filter(Boolean)
        .join(' | ');

      const pantNotes = [
        order.pantMeasurements?.handWrittenNotes,
        order.pantMeasurements?.extraNotes,
      ]
        .filter(Boolean)
        .join(' | ');

      if (resolvedType === 'Shirt') {
        cards.push({
          key: `item-${originalIndex}-shirt`,
          headerTitle,
          ribbonText,
          branchText,
          itemNameText: `Item: ${item.name}${qtySuffix}${ivSuffix}`,
          measurementsText: formatShirtMeasurementsSlip(order.shirtMeasurements),
          notesText: shirtNotes || undefined,
          partName: 'Shirt',
          dateText,
        });
      } else if (resolvedType === 'Pant') {
        cards.push({
          key: `item-${originalIndex}-pant`,
          headerTitle,
          ribbonText,
          branchText,
          itemNameText: `Item: ${item.name}${qtySuffix}${ivSuffix}`,
          measurementsText: formatPantMeasurementsSlip(order.pantMeasurements),
          notesText: pantNotes || undefined,
          partName: 'Pant',
          dateText,
        });
      } else {
        // 'Shirt + Pant' -> two separate slips (Shirt first, Pant second)
        cards.push({
          key: `item-${originalIndex}-set-shirt`,
          headerTitle,
          ribbonText,
          branchText,
          itemNameText: `Item: ${item.name} (Shirt)${qtySuffix}${ivSuffix}`,
          measurementsText: formatShirtMeasurementsSlip(order.shirtMeasurements),
          notesText: shirtNotes || undefined,
          partName: 'Shirt',
          dateText,
        });
        cards.push({
          key: `item-${originalIndex}-set-pant`,
          headerTitle,
          ribbonText,
          branchText,
          itemNameText: `Item: ${item.name} (Pant)${qtySuffix}${ivSuffix}`,
          measurementsText: formatPantMeasurementsSlip(order.pantMeasurements),
          notesText: pantNotes || undefined,
          partName: 'Pant',
          dateText,
        });
      }
    });

    return cards;
  }, [order, isOfficer, officerOrder, airmanOrder, itemIndex, state.settings.items, state.settings.airmanItems]);

  return (
    <div className="min-h-screen bg-gray-100 py-6 print:py-0 print:bg-white">
      {/* Top Controls Toolbar (Hidden in print) */}
      <div className="max-w-4xl mx-auto px-4 mb-6 print:hidden flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => onNavigate(order ? 'order-details' : 'staff-management', { orderNumber, category, workerId })}
            className="px-3 py-1.5 border border-gray-300 rounded-xl text-xs font-semibold text-gray-700 hover:bg-gray-50 flex items-center space-x-1.5 cursor-pointer active:scale-95"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>
          <span className="text-sm font-bold text-gray-900">
            {type === 'slip'
              ? `Cutting Slip — #${orderNumber}`
              : type === 'invoice'
              ? `Invoice #${orderNumber}`
              : `Staff Statement — ${worker?.name}`}
          </span>
          <span className="text-xs px-2 py-0.5 rounded-md bg-gray-100 text-gray-600 font-mono">
            {paperSize}
          </span>
        </div>

        {/* Invoice Variant Selector (Customer Invoice vs Shop Record Invoice) */}
        {type === 'invoice' && (
          <div className="flex items-center p-1 bg-gray-100 rounded-xl border border-gray-200/80">
            <button
              type="button"
              onClick={() => setInvoiceVariant('customer')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                invoiceVariant === 'customer'
                  ? 'bg-white text-[#5C1221] shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Customer Invoice</span>
            </button>
            <button
              type="button"
              onClick={() => setInvoiceVariant('shop')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                invoiceVariant === 'shop'
                  ? 'bg-white text-[#5C1221] shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Shop Record (Workshop)</span>
            </button>
          </div>
        )}

        <div className="flex items-center space-x-2">
          {/* Switch to cutting slip */}
          {type === 'invoice' && (
            <button
              onClick={() => onNavigate('print-slip', { orderNumber, category: 'Officer' })}
              className="px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-100 rounded-xl flex items-center space-x-1 cursor-pointer"
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>Cutting Slip</span>
            </button>
          )}

          {type === 'slip' && isOfficer && (
            <button
              onClick={() => onNavigate('print-invoice', { orderNumber, category: 'Officer' })}
              className="px-3 py-1.5 text-xs font-medium text-gray-700 hover:bg-gray-100 rounded-xl flex items-center space-x-1 cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Invoice</span>
            </button>
          )}

          {/* Download PDF Button */}
          {type === 'invoice' && (
            <button
              type="button"
              onClick={handleDownloadInvoicePDF}
              className="px-3.5 py-1.5 btn-3d btn-3d-white text-xs font-bold flex items-center space-x-1.5"
            >
              <Download className="w-3.5 h-3.5 text-[#5C1221]" />
              <span>Download PDF</span>
            </button>
          )}

          <button
            onClick={handlePrint}
            className="px-4 py-1.5 btn-3d btn-3d-maroon text-xs font-bold flex items-center space-x-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Document</span>
          </button>
        </div>
      </div>

      {/* Printable Sheet Area */}
      <div
        className={`mx-auto bg-white border border-gray-300 shadow-lg print:border-0 print:shadow-none print:m-0 print:p-0 ${
          paperSize === 'A5' ? 'max-w-[148mm] min-h-[210mm] p-6' : 'max-w-[210mm] min-h-[297mm] p-8'
        }`}
      >
        {/* ================= TYPE: CUTTING SLIP ================= */}
        {type === 'slip' && order && (
          <div className="text-black font-sans space-y-3">
            {/* Top header bar */}
            <div className="pb-2 border-b border-gray-300 flex items-center justify-between print:pb-1">
              <div>
                <span className="text-[14px] font-extrabold uppercase tracking-wider">
                  {state.settings.invoiceShopName || 'BAF Tailor & Outfitters'}
                </span>
                <span className="ml-2 text-[11px] font-semibold text-gray-600 print:text-black">
                  — {category} Cutting {itemIndex !== undefined ? 'Slip' : 'Slips'} ({slipCards.length} {slipCards.length === 1 ? 'slip' : 'slips'})
                </span>
              </div>
              <span className="text-[10px] text-gray-500 print:text-black font-mono">
                Order #{order.orderNumber}
              </span>
            </div>

            {slipCards.length === 0 ? (
              <div className="p-8 text-center text-gray-500 italic">
                No cutting slips found for this item selection.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 print:grid-cols-2 print:gap-3">
                {slipCards.map((card) => (
                  <div
                    key={card.key}
                    className="border-2 border-black p-3.5 rounded-lg bg-white text-black flex flex-col justify-between"
                    style={{ breakInside: 'avoid', pageBreakInside: 'avoid' }}
                  >
                    <div>
                      {/* Top Header: #546 ~ S/L ERFAN ~ 10133 */}
                      <div className="flex items-start justify-between border-b-2 border-black pb-1.5 mb-2 gap-2">
                        <div className="font-extrabold text-[13px] tracking-tight leading-snug">
                          {card.headerTitle}
                        </div>
                        <div className="text-right shrink-0 text-[11px] font-bold">
                          {card.ribbonText && <div>{card.ribbonText}</div>}
                          {card.branchText && (
                            <div className="text-[10px] uppercase font-bold text-gray-800">
                              {card.branchText}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Item Line: Item: [Name] (Qty N) [~ IV: ...] */}
                      <div className="font-bold text-[12px] mb-1.5 text-gray-900">
                        {card.itemNameText}
                      </div>

                      {/* Thin divider */}
                      <div className="border-b border-black mb-2" />

                      {/* Measurement line: joined by ~ */}
                      <div className="text-[11px] font-medium leading-relaxed tracking-tight text-black">
                        {card.measurementsText}
                      </div>

                      {/* Notes line in bold */}
                      {card.notesText && (
                        <div className="mt-2 pt-1.5 border-t border-dashed border-gray-400 text-[11px] font-bold text-black">
                          <span className="uppercase text-[10px] tracking-wide underline mr-1">
                            Notes:
                          </span>
                          {card.notesText}
                        </div>
                      )}
                    </div>

                    {/* Bottom Line: Part name on left, date on right */}
                    <div className="mt-3 pt-1.5 border-t border-black flex items-center justify-between text-[10px] font-extrabold uppercase tracking-wider">
                      <span className="px-1.5 py-0.5 rounded bg-black text-white">
                        {card.partName}
                      </span>
                      <span className="text-gray-800">{card.dateText}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TYPE: INVOICE (RAYMOND BURGUNDY & GOLD DUAL INVOICE) ================= */}
        {type === 'invoice' && officerOrder && (
          <div className="text-black font-sans space-y-4 text-xs select-none">
            {/* Header: Deep Burgundy with Gold Trim Line */}
            <div className="bg-[#5C1221] text-white p-4 sm:p-5 rounded-t-xl -mx-8 -mt-8 relative overflow-hidden">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h1 className="text-lg sm:text-xl font-black uppercase tracking-wider text-white">
                    {state.settings.invoiceShopName || 'ONE RAYMOND TAILORS & FABRICS'}
                  </h1>
                  <div className="text-[11px] text-[#F5D073] flex flex-wrap items-center gap-3 mt-1 font-medium">
                    <span className="flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      <span>{state.settings.invoiceShopPhone || '01784161522 / 01333255692'}</span>
                    </span>
                    <span>·</span>
                    <span>BAF Base Bashar, Dhaka Cant</span>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] font-bold tracking-widest text-[#F5D073] uppercase block">
                    {invoiceVariant === 'customer' ? 'DELIVERY INVOICE' : 'WORKSHOP ORDER RECORD'}
                  </span>
                  {/* Order ID IS THE BIGGEST ELEMENT */}
                  <span className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                    #{officerOrder.orderNumber}
                  </span>
                </div>
              </div>

              {/* Gold Accent Strip */}
              <div className="absolute bottom-0 inset-x-0 h-1 bg-[#D4AF37]" />
            </div>

            {/* Customer Details & Order Dates (Dual Box layout) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {/* Bill To Box */}
              <div className="p-3.5 bg-gray-50/80 rounded-xl border border-gray-200">
                <div className="inline-block px-2.5 py-0.5 rounded bg-[#5C1221] text-white text-[10px] font-bold uppercase tracking-wider mb-2">
                  BILL TO
                </div>
                <div className="font-extrabold text-sm text-gray-950">{officerOrder.customerName}</div>
                <div className="text-xs text-gray-600 mt-1 flex items-center gap-2">
                  <span className="font-semibold text-gray-500">BD NUMBER:</span>
                  <span className="font-bold font-mono text-[#5C1221]">{officerOrder.customerBdNumber}</span>
                  {officerOrder.branch && (
                    <span className="text-[10px] px-1.5 py-0.2 bg-blue-100 text-blue-800 rounded font-bold">
                      {officerOrder.branch}
                    </span>
                  )}
                </div>
                {officerOrder.customerPhone && (
                  <div className="text-[11px] text-gray-500 mt-1 font-mono">
                    Phone: {officerOrder.customerPhone}
                  </div>
                )}
              </div>

              {/* Dates Box */}
              <div className="p-3.5 bg-gray-50/80 rounded-xl border border-gray-200 flex flex-col justify-between">
                <div>
                  <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">ORDER DATE</div>
                  <div className="font-bold text-xs text-gray-900 font-mono mt-0.5">{officerOrder.orderDate}</div>
                </div>
                <div className="mt-2 pt-2 border-t border-gray-200">
                  <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">DELIVERY DATE</div>
                  <div className="font-bold text-xs text-[#5C1221] font-mono mt-0.5">
                    {officerOrder.deliveryDate || '—'}
                  </div>
                </div>
              </div>
            </div>

            {/* IF SHOP RECORD INVOICE: Show Complete Measurements Matrix */}
            {invoiceVariant === 'shop' && (
              <div className="border border-gray-300 rounded-xl overflow-hidden my-3">
                <div className="bg-gray-900 text-white px-3 py-1.5 text-xs font-bold uppercase tracking-wider">
                  Workshop Cutting & Tailoring Measurements
                </div>
                <div className="p-3 bg-gray-50/50 space-y-2 text-[11px]">
                  {/* Shirt Measurements */}
                  {officerOrder.shirtMeasurements && (
                    <div>
                      <span className="font-bold text-gray-900 uppercase text-[10px] block mb-1">
                        Shirt Specifications:
                      </span>
                      <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 bg-white p-2 rounded-lg border border-gray-200 font-mono text-center">
                        <div><span className="text-[9px] text-gray-400 block">Length</span>{officerOrder.shirtMeasurements.length || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Chest</span>{officerOrder.shirtMeasurements.chest || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Belly</span>{officerOrder.shirtMeasurements.belly || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Shoulder</span>{officerOrder.shirtMeasurements.shoulder || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Sleeve</span>{officerOrder.shirtMeasurements.sleeve || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Collar</span>{officerOrder.shirtMeasurements.collar || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Front</span>{officerOrder.shirtMeasurements.front || '—'}</div>
                      </div>
                    </div>
                  )}

                  {/* Pant Measurements */}
                  {officerOrder.pantMeasurements && (
                    <div className="mt-2">
                      <span className="font-bold text-gray-900 uppercase text-[10px] block mb-1">
                        Pant Specifications:
                      </span>
                      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 bg-white p-2 rounded-lg border border-gray-200 font-mono text-center">
                        <div><span className="text-[9px] text-gray-400 block">Length</span>{officerOrder.pantMeasurements.length || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Waist</span>{officerOrder.pantMeasurements.waist || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Hip</span>{officerOrder.pantMeasurements.hip || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">High</span>{officerOrder.pantMeasurements.high || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Thai</span>{officerOrder.pantMeasurements.thai || '—'}</div>
                        <div><span className="text-[9px] text-gray-400 block">Bottom</span>{officerOrder.pantMeasurements.legOpen || '—'}</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Items Table with Burgundy Header */}
            <div className="border border-gray-300 rounded-xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-[#5C1221] text-white">
                    <th className="p-2.5 w-10 text-center font-bold">#</th>
                    <th className="p-2.5 font-bold">ITEM NAME</th>
                    <th className="p-2.5 w-16 text-center font-bold">QTY</th>
                    <th className="p-2.5 w-24 text-right font-bold">PRICE</th>
                    <th className="p-2.5 w-28 text-right font-bold">TOTAL</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {officerOrder.items.map((item, idx) => (
                    <tr key={idx} className={idx % 2 === 1 ? 'bg-gray-50/70' : 'bg-white'}>
                      <td className="p-2.5 text-center font-mono font-medium text-gray-500">{idx + 1}</td>
                      <td className="p-2.5 font-bold text-gray-900">{item.name}</td>
                      <td className="p-2.5 text-center font-semibold">{item.quantity}</td>
                      <td className="p-2.5 text-right font-mono">BDT {item.price.toLocaleString()}</td>
                      <td className="p-2.5 text-right font-bold font-mono text-gray-950">
                        BDT {item.lineTotal.toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Financial Calculations Block & Gold Due Banner */}
            <div className="flex justify-end pt-2">
              <div className="w-72 space-y-2 text-xs">
                <div className="flex justify-between py-1 border-b border-gray-200 text-gray-600">
                  <span>Subtotal:</span>
                  <span className="font-bold text-gray-950 font-mono">
                    BDT {officerOrder.totalAmount.toLocaleString()}
                  </span>
                </div>
                {officerOrder.discountAmount > 0 && (
                  <div className="flex justify-between py-1 border-b border-gray-200 text-emerald-700">
                    <span>Discount:</span>
                    <span className="font-bold font-mono">
                      - BDT {officerOrder.discountAmount.toLocaleString()}
                    </span>
                  </div>
                )}
                <div className="flex justify-between py-1 border-b border-gray-200 text-emerald-700">
                  <span>Advance Paid:</span>
                  <span className="font-bold font-mono">
                    - BDT {(officerOrder.advance || 0).toLocaleString()}
                  </span>
                </div>

                {/* THE ICONIC GOLD/AMBER DUE BANNER (matching screenshot #E5A824) */}
                <div className="bg-[#E5A824] text-white p-3 rounded-xl flex items-center justify-between font-extrabold text-sm shadow-sm mt-2">
                  <span>DUE</span>
                  <span className="font-mono text-base">BDT {officerOrder.due.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Shop Record Signature Block */}
            {invoiceVariant === 'shop' && (
              <div className="grid grid-cols-2 gap-8 pt-10 pb-4 text-center">
                <div>
                  <div className="border-t border-gray-400 pt-2 text-xs font-semibold text-gray-700">
                    Cutter Master Signature
                  </div>
                </div>
                <div>
                  <div className="border-t border-gray-400 pt-2 text-xs font-semibold text-gray-700">
                    Workshop Manager Sign-off
                  </div>
                </div>
              </div>
            )}

            {/* Footer with motto, address & dashed cut line */}
            <div className="pt-6 -mx-8 -mb-8">
              <div className="border-t-2 border-dashed border-gray-300 py-2 text-center text-[10px] text-gray-400">
                ✂ - - - - - - - - - - - - - - - - - Cut Here - - - - - - - - - - - - - - - - - ✂
              </div>
              <div className="bg-[#5C1221] text-white text-center py-3.5 px-4 rounded-b-xl space-y-1">
                <div className="text-[11px] font-bold text-[#F5D073] tracking-wide">
                  Quality Tailoring  |  Timely Delivery  |  Customer Satisfaction
                </div>
                <div className="text-[10px] text-gray-200">
                  Address: {state.settings.invoiceShopAddress || 'Base tailor shop, BAF base bashar, Dhaka cant 1206'}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= TYPE: WORKER STATEMENT ================= */}
        {type === 'worker-statement' && worker && month && (
          <div className="text-black font-sans space-y-4 text-xs">
            <div className="border-b-2 border-black pb-3 text-center">
              <h1 className="text-xl font-extrabold uppercase">
                {state.settings.invoiceShopName || 'BAF Tailor & Outfitters'}
              </h1>
              <div className="text-base font-bold underline mt-1">Staff Monthly Statement</div>
              <div className="text-sm font-semibold mt-1">
                Worker: {worker.name} {worker.banglaName && `(${worker.banglaName})`} · Month: {month}
              </div>
            </div>

            {/* Grid rows */}
            {(() => {
              const rows = state.workerRows.filter((r) => {
                if (r.workerId !== worker.id) return false;
                const rMonth = (r.date || '').slice(0, 7);
                const kMonth = (r.khorochDate || r.date || '').slice(0, 7);
                return rMonth === month || kMonth === month;
              });

              const payments = state.workerPayments.filter(
                (p) => p.workerId === worker.id && p.forMonth === month
              );

              const hishab = calculateWorkerMonthHishab(worker.id, state.workerRows, state.workerPayments, month);

              return (
                <div className="space-y-4">
                  <table className="w-full text-left border border-black text-[11px]">
                    <thead>
                      <tr className="border-b border-black bg-gray-100 font-bold">
                        <th className="p-1 border-r border-black">Date</th>
                        <th className="p-1 border-r border-black">Serial</th>
                        <th className="p-1 border-r border-black">BD</th>
                        <th className="p-1 border-r border-black">Item</th>
                        <th className="p-1 border-r border-black text-center">Qty</th>
                        <th className="p-1 border-r border-black text-right">Rate</th>
                        <th className="p-1 border-r border-black text-right">Total</th>
                        <th className="p-1 text-right">Khoroch</th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((r, i) => (
                        <tr key={i} className="border-b border-gray-300">
                          <td className="p-1 border-r border-black">{r.date}</td>
                          <td className="p-1 border-r border-black font-semibold">#{r.serial}</td>
                          <td className="p-1 border-r border-black">{r.bdNumber}</td>
                          <td className="p-1 border-r border-black">{r.item}</td>
                          <td className="p-1 border-r border-black text-center">{r.quantity}</td>
                          <td className="p-1 border-r border-black text-right">৳{r.unitPrice}</td>
                          <td className="p-1 border-r border-black text-right font-semibold">
                            ৳{r.totalTaka}
                          </td>
                          <td className="p-1 text-right font-semibold text-amber-900">
                            {r.khoroch ? `৳${r.khoroch}` : '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Payments list in statement (Loop 8 Section 3) */}
                  {payments.length > 0 && (
                    <div className="border border-black p-2 rounded">
                      <span className="font-bold underline block mb-1">Settlement Payments Received:</span>
                      <div className="space-y-0.5">
                        {payments.map((p, idx) => (
                          <div key={idx} className="flex justify-between">
                            <span>{p.date} {p.note && `(${p.note})`}</span>
                            <span className="font-bold">৳{p.amount}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Footer Totals */}
                  <div className="border-t-2 border-black pt-2 flex justify-end">
                    <div className="w-56 space-y-1 font-semibold">
                      <div className="flex justify-between">
                        <span>Total Work Earned:</span>
                        <span>৳{hishab.totalAmount}</span>
                      </div>
                      <div className="flex justify-between text-amber-800">
                        <span>Total Khoroch:</span>
                        <span>-৳{hishab.totalKhoroch}</span>
                      </div>
                      <div className="flex justify-between border-t border-black pt-0.5 font-bold">
                        <span>Net Payable:</span>
                        <span>৳{hishab.netPayable}</span>
                      </div>
                      <div className="flex justify-between text-emerald-800">
                        <span>Received Payments:</span>
                        <span>-৳{hishab.received}</span>
                      </div>
                      <div className="flex justify-between border-t-2 border-black pt-1 font-extrabold text-sm">
                        <span>Balance Due:</span>
                        <span>৳{hishab.due}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
