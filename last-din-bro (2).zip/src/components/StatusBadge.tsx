import React from 'react';
import { OrderStatus } from '../types/index.ts';

interface StatusBadgeProps {
  status: OrderStatus;
  onChange?: (newStatus: OrderStatus) => void;
  interactive?: boolean;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({
  status,
  onChange,
  interactive = false,
  className = '',
}) => {
  const renderStatusDot = (st: OrderStatus) => {
    switch (st) {
      case 'Pending':
        return <span className="w-2 h-2 rounded-full bg-[#f2a93b] mr-1.5 shrink-0" />;
      case 'Cutting Slip – Done':
        return <span className="w-2 h-2 rounded-full bg-[#7a4fd2] mr-1.5 shrink-0" />;
      case 'Delivered':
        return <span className="w-2 h-2 rounded-full bg-[#2e9e54] mr-1.5 shrink-0" />;
      default:
        return <span className="w-2 h-2 rounded-full bg-[#6e6e73] mr-1.5 shrink-0" />;
    }
  };

  const getStatusStyles = (st: OrderStatus) => {
    switch (st) {
      case 'Pending':
        return 'bg-[#fdeee7] text-[#c2410c] border border-[#fa7e42]/30';
      case 'Cutting Slip – Done':
        return 'bg-[#f3e8ff] text-[#6b21a8] border border-[#c084fc]/30';
      case 'Delivered':
        return 'bg-[#e3f4e8] text-[#1e7b43] border border-[#2e9e54]/30';
      default:
        return 'bg-[#f5f5f7] text-[#6e6e73] border border-[#e0e0e0]';
    }
  };

  if (!interactive || !onChange) {
    return (
      <span
        className={`inline-flex items-center h-[24px] px-2.5 rounded-full text-[12px] font-semibold whitespace-nowrap ${getStatusStyles(
          status
        )} ${className}`}
      >
        {renderStatusDot(status)}
        <span>{status}</span>
      </span>
    );
  }

  return (
    <div className={`relative inline-flex items-center ${className}`}>
      <span className="absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none">
        {renderStatusDot(status)}
      </span>
      <select
        value={status}
        onChange={(e) => {
          e.stopPropagation();
          onChange(e.target.value as OrderStatus);
        }}
        onClick={(e) => e.stopPropagation()}
        aria-label="Order status"
        className={`h-[26px] text-[12px] font-semibold rounded-full pl-6 pr-5 cursor-pointer outline-none transition-colors ${getStatusStyles(
          status
        )}`}
      >
        <option value="Pending" className="bg-white text-[#c2410c]">
          Pending
        </option>
        <option value="Cutting Slip – Done" className="bg-white text-[#6b21a8]">
          Cutting Slip – Done
        </option>
        <option value="Delivered" className="bg-white text-[#1e7b43]">
          Delivered
        </option>
      </select>
    </div>
  );
};
