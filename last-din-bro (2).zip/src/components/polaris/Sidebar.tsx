import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import { ManageItemsModal } from '../ManageItemsModal.tsx';
import { PWAInstallButton } from '../PWAInstallButton.tsx';
import {
  LayoutDashboard,
  ClipboardList,
  Plane,
  Truck,
  FileText,
  Users,
  History,
  UserCheck,
  BarChart3,
  Settings,
  X,
  Scissors,
  ChevronLeft,
  ChevronRight,
  Tag,
} from 'lucide-react';

interface SidebarProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

interface NavGroup {
  groupTitle?: string;
  items: {
    id: ScreenName;
    label: string;
    icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
    badge?: number;
    activeScreenMatches?: ScreenName[];
  }[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentScreen,
  onNavigate,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  const { state } = useApp();
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('raymond_sidebar_collapsed') === 'true';
    } catch {
      return false;
    }
  });
  const [managePricesOpen, setManagePricesOpen] = useState<boolean>(false);

  const toggleCollapsed = () => {
    setCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('raymond_sidebar_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  // Lock body scroll on mobile when menu is open
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const draftsCount = state.drafts.length;

  const navGroups: NavGroup[] = [
    {
      groupTitle: 'Operations',
      items: [
        {
          id: 'dashboard',
          label: 'Dashboard',
          icon: LayoutDashboard,
        },
        {
          id: 'orders',
          label: 'Officer Orders',
          icon: ClipboardList,
          activeScreenMatches: ['new-officer-order', 'edit-officer-order', 'order-details'],
        },
        {
          id: 'airman-orders',
          label: 'Airman Orders',
          icon: Plane,
          activeScreenMatches: ['new-airman-order', 'edit-airman-order'],
        },
        {
          id: 'delivery',
          label: 'Deliveries',
          icon: Truck,
        },
        {
          id: 'drafts',
          label: 'Draft Orders',
          icon: FileText,
          badge: draftsCount > 0 ? draftsCount : undefined,
        },
      ],
    },
    {
      groupTitle: 'Management',
      items: [
        {
          id: 'customers',
          label: 'Customers',
          icon: Users,
        },
        {
          id: 'customer-history',
          label: 'Customer History',
          icon: History,
        },
        {
          id: 'staff-management',
          label: 'Staff Management',
          icon: UserCheck,
          activeScreenMatches: ['worker-page'],
        },
        {
          id: 'staff-summary',
          label: 'Staff Hishab',
          icon: BarChart3,
          activeScreenMatches: ['worker-history'],
        },
      ],
    },
  ];

  const handleItemClick = (id: ScreenName) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  const isSelected = (item: NavGroup['items'][0]) => {
    if (currentScreen === item.id) return true;
    if (item.activeScreenMatches && item.activeScreenMatches.includes(currentScreen)) {
      return true;
    }
    return false;
  };

  const isSettingsSelected = currentScreen === 'settings';

  const renderNavContent = (isMobile: boolean) => (
    <div className="flex flex-col h-full justify-between">
      {/* Top Section: Nav Links */}
      <div className="space-y-4 overflow-y-auto no-scrollbar flex-1 px-2.5 py-3">
        {navGroups.map((group, groupIdx) => (
          <div key={groupIdx} className="space-y-1">
            {group.groupTitle && (!collapsed || isMobile) && (
              <div className="px-3 pt-2 pb-1 text-[11px] font-semibold uppercase tracking-wider text-[#616161]">
                {group.groupTitle}
              </div>
            )}
            {collapsed && !isMobile && groupIdx > 0 && (
              <div className="w-8 h-px bg-[#D9D9D9] mx-auto my-2" />
            )}

            <nav className="space-y-1">
              {group.items.map((item) => {
                const active = isSelected(item);
                const Icon = item.icon;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleItemClick(item.id)}
                    aria-current={active ? 'page' : undefined}
                    title={collapsed && !isMobile ? item.label : undefined}
                    className={`w-full h-[36px] rounded-[8px] flex items-center transition-colors text-[13px] cursor-pointer group relative ${
                      collapsed && !isMobile
                        ? 'justify-center px-0'
                        : 'justify-between px-3'
                    } ${
                      active
                        ? 'bg-white text-[#1A1A1A] font-semibold shadow-[0_1px_2px_rgba(26,26,26,0.06),0_0_0_1px_rgba(26,26,26,0.05)]'
                        : 'text-[#303030] hover:bg-[#E3E3E3]/70 hover:text-[#1A1A1A] font-[450]'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5 min-w-0 overflow-hidden">
                      <Icon
                        className={`w-4 h-4 shrink-0 transition-colors ${
                          active
                            ? 'text-[#005BD3]'
                            : 'text-[#616161] group-hover:text-[#1A1A1A]'
                        }`}
                        strokeWidth={active ? 2.2 : 1.75}
                      />
                      {(!collapsed || isMobile) && (
                        <span className="truncate whitespace-nowrap">{item.label}</span>
                      )}
                    </div>

                    {/* Active Accent Pill Bar */}
                    {active && (
                      <div className="absolute left-0 top-1.5 bottom-1.5 w-1 bg-[#005BD3] rounded-r-full" />
                    )}

                    {/* Notification Badge */}
                    {(!collapsed || isMobile) &&
                      item.badge !== undefined &&
                      item.badge > 0 && (
                        <span className="text-[11px] font-bold px-1.5 py-0.2 rounded-full bg-[#E3E3E3] text-[#303030] shrink-0">
                          {item.badge}
                        </span>
                      )}

                    {/* Collapsed dot badge */}
                    {collapsed &&
                      !isMobile &&
                      item.badge !== undefined &&
                      item.badge > 0 && (
                        <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#D72C35]" />
                      )}
                  </button>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      {/* Bottom Section: Quick Item Prices + Settings + Rail Collapse */}
      <div className="p-2.5 border-t border-[#E3E3E3] space-y-1 bg-[#EBEBEB] shrink-0">
        {/* Quick Item Prices Shortcut */}
        <button
          type="button"
          onClick={() => {
            setManagePricesOpen(true);
            if (isMobile) setMobileMenuOpen(false);
          }}
          title={collapsed && !isMobile ? 'Manage Items & Prices' : undefined}
          className={`w-full h-[36px] rounded-[8px] flex items-center transition-colors text-[13px] font-medium cursor-pointer text-[#005BD3] hover:bg-white hover:text-[#0047A5] border border-blue-200/60 bg-blue-50/50 ${
            collapsed && !isMobile ? 'justify-center px-0' : 'space-x-2.5 px-3'
          }`}
        >
          <Tag className="w-4 h-4 shrink-0 text-[#005BD3]" strokeWidth={2} />
          {(!collapsed || isMobile) && (
            <span className="truncate whitespace-nowrap font-semibold">Item Prices Shortcut</span>
          )}
        </button>

        {/* PWA In-App Install prompt */}
        {(!collapsed || isMobile) && (
          <div className="py-0.5">
            <PWAInstallButton variant="settings" className="w-full justify-center text-xs py-1.5" />
          </div>
        )}

        {/* Settings */}
        <button
          onClick={() => handleItemClick('settings')}
          aria-current={isSettingsSelected ? 'page' : undefined}
          title={collapsed && !isMobile ? 'Settings' : undefined}
          className={`w-full h-[36px] rounded-[8px] flex items-center transition-colors text-[13px] cursor-pointer ${
            collapsed && !isMobile ? 'justify-center px-0' : 'space-x-2.5 px-3'
          } ${
            isSettingsSelected
              ? 'bg-white text-[#1A1A1A] font-semibold shadow-[0_1px_2px_rgba(26,26,26,0.06),0_0_0_1px_rgba(26,26,26,0.05)]'
              : 'text-[#303030] hover:bg-[#E3E3E3]/70 hover:text-[#1A1A1A] font-[450]'
          }`}
        >
          <Settings
            className={`w-4 h-4 shrink-0 ${
              isSettingsSelected ? 'text-[#005BD3]' : 'text-[#616161]'
            }`}
            strokeWidth={isSettingsSelected ? 2.2 : 1.75}
          />
          {(!collapsed || isMobile) && (
            <span className="truncate whitespace-nowrap">Settings</span>
          )}
        </button>

        {/* Desktop Rail Collapse Toggle */}
        {!isMobile && (
          <div className="pt-1">
            <button
              type="button"
              onClick={toggleCollapsed}
              title={collapsed ? 'Expand sidebar' : 'Collapse to rail'}
              className="w-full h-[30px] rounded-[6px] text-[#616161] hover:text-[#1A1A1A] hover:bg-[#E3E3E3] flex items-center justify-center transition-colors text-[11px] font-medium cursor-pointer"
            >
              {collapsed ? (
                <ChevronRight className="w-4 h-4" />
              ) : (
                <div className="flex items-center space-x-1.5">
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Collapse sidebar</span>
                </div>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* =========================================================================
          DESKTOP SIDEBAR (Polaris Era 2025: --surface-sidebar #EBEBEB)
          Rock-solid, non-glitch layout with stable width transitions
         ========================================================================= */}
      <aside
        className={`hidden md:flex flex-col shrink-0 h-full bg-[#EBEBEB] border-r border-[#E3E3E3] select-none transition-[width] duration-200 ease-out ${
          collapsed ? 'w-[68px]' : 'w-[240px]'
        }`}
        style={{
          backgroundColor: 'var(--surface-sidebar, #EBEBEB)',
          borderColor: 'var(--border-default, #E3E3E3)',
        }}
        aria-label="Main desktop navigation"
      >
        {renderNavContent(false)}
      </aside>

      {/* =========================================================================
          MOBILE DRAWER (Fluid Spring Animation with No Glitch)
         ========================================================================= */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            {/* Scrim / Backdrop with gentle fade */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/50 backdrop-blur-xs"
              onClick={() => setMobileMenuOpen(false)}
              aria-hidden="true"
            />

            {/* Sliding Drawer Container */}
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 28, stiffness: 350 }}
              className="relative z-10 w-[270px] max-w-[85vw] h-full bg-[#EBEBEB] text-[#303030] flex flex-col justify-between shadow-2xl border-r border-[#E3E3E3]"
              aria-label="Mobile navigation menu"
            >
              {/* Mobile Drawer Header */}
              <div className="h-[56px] px-4 flex items-center justify-between border-b border-[#E3E3E3] bg-[#EBEBEB] shrink-0">
                <div className="flex items-center space-x-2.5">
                  <div className="w-8 h-8 rounded-lg bg-[#1A1A1A] flex items-center justify-center text-white shadow-xs">
                    <Scissors className="w-4 h-4 -rotate-45" />
                  </div>
                  <div>
                    <span className="font-bold text-[14px] text-[#1A1A1A] leading-tight block">
                      Raymond
                    </span>
                    <span className="text-[11px] text-[#616161]">BAF Tailor Studio</span>
                  </div>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-8 h-8 rounded-lg text-[#616161] hover:text-[#1A1A1A] hover:bg-[#E3E3E3] flex items-center justify-center transition-colors cursor-pointer"
                  aria-label="Close navigation"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Navigation Body */}
              <div className="flex-1 overflow-hidden min-h-0">
                {renderNavContent(true)}
              </div>
            </motion.aside>
          </div>
        )}
      </AnimatePresence>

      {/* Global Manage Items & Prices Modal */}
      <ManageItemsModal
        isOpen={managePricesOpen}
        onClose={() => setManagePricesOpen(false)}
        initialTab="officer"
      />
    </>
  );
};
