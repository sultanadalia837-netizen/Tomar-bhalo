import React from 'react';

export interface PolarisCardProps {
  title?: string;
  subtitle?: string;
  actions?: React.ReactNode;
  children: React.ReactNode;
  flush?: boolean;
  className?: string;
}

export const PolarisCard: React.FC<PolarisCardProps> = ({
  title,
  subtitle,
  actions,
  children,
  flush = false,
  className = '',
}) => {
  return (
    <div
      className={`bg-white rounded-[24px] border border-[#e0e0e0] transition-shadow ${className}`}
      style={{
        backgroundColor: 'var(--canvas)',
        borderColor: 'var(--hairline)',
        borderRadius: 'var(--r-panel)',
      }}
    >
      {(title || actions) && (
        <div className="px-5 sm:px-6 py-4 border-b border-[#f0f0f0] flex items-center justify-between gap-3">
          <div>
            <h2 className="text-[17px] leading-[22px] font-semibold text-[#1d1d1f] m-0">
              {title}
            </h2>
            {subtitle && (
              <p className="text-[14px] leading-[20px] text-[#6e6e73] mt-0.5 font-normal">{subtitle}</p>
            )}
          </div>
          {actions && <div className="shrink-0 flex items-center space-x-2">{actions}</div>}
        </div>
      )}

      <div className={flush ? '' : 'p-5 sm:p-6'}>{children}</div>
    </div>
  );
};

export const PolarisCardSection: React.FC<{
  children: React.ReactNode;
  title?: string;
  inset?: boolean;
  className?: string;
}> = ({ children, title, inset = false, className = '' }) => {
  return (
    <div
      className={`p-4 sm:p-5 border-t border-[#f0f0f0] first:border-t-0 ${
        inset ? 'bg-[#f5f5f7] rounded-[16px] m-3 sm:m-4' : 'bg-white'
      } ${className}`}
    >
      {title && (
        <h3 className="text-[13px] font-[650] text-[#303030] mb-2">{title}</h3>
      )}
      {children}
    </div>
  );
};
