import React from 'react';
import { ArrowLeft } from 'lucide-react';

export interface ActionItem {
  label?: string;
  content?: string;
  onClick?: () => void;
  onAction?: () => void;
  icon?: React.ReactNode;
  disabled?: boolean;
}

export interface PolarisPageProps {
  title: string;
  subtitle?: string;
  badge?: React.ReactNode;
  backAction?: () => void;
  primaryAction?: ActionItem;
  secondaryActions?: ActionItem[];
  children: React.ReactNode;
  fullWidth?: boolean;
}

export const PolarisPage: React.FC<PolarisPageProps> = ({
  title,
  subtitle,
  badge,
  backAction,
  primaryAction,
  secondaryActions = [],
  children,
  fullWidth = false,
}) => {
  return (
    <div className="min-h-full text-[#1d1d1f] pb-12">
      {/* Max Width Container */}
      <div className={`mx-auto space-y-5 ${fullWidth ? 'max-w-7xl' : 'max-w-[1200px]'}`}>
        {/* Page Header (H1: 32-36px, 600 weight, tight tracking; subtitle: 15-17px ink-60) */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pt-2">
          {/* Left: Back Arrow + Title + Subtitle */}
          <div className="flex items-center space-x-3">
            {backAction && (
              <button
                onClick={backAction}
                className="w-9 h-9 rounded-full flex items-center justify-center text-[#1d1d1f] hover:bg-[#e5e5ea] border border-[#e0e0e0] bg-white transition-transform active:scale-95 cursor-pointer shrink-0"
                aria-label="Back"
              >
                <ArrowLeft className="w-4 h-4 stroke-[2.2]" />
              </button>
            )}
            <div>
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="text-[26px] sm:text-[32px] font-semibold text-[#1d1d1f] tracking-[-0.03em] leading-tight">
                  {title}
                </h1>
                {badge && <div className="shrink-0">{badge}</div>}
              </div>
              {subtitle && (
                <p className="text-[15px] leading-[22px] text-[#6e6e73] font-normal mt-0.5">
                  {subtitle}
                </p>
              )}
            </div>
          </div>

          {/* Right: Actions Cluster (Ghost first, Primary last) */}
          {(secondaryActions.length > 0 || primaryAction) && (
            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              {secondaryActions.map((action, idx) => {
                const clickHandler = action.onClick || action.onAction;
                const text = action.label || action.content;
                return (
                  <button
                    key={idx}
                    onClick={clickHandler}
                    disabled={action.disabled}
                    className="min-h-[42px] px-4 rounded-full bg-white hover:bg-[#f5f5f7] active:scale-95 text-[#0066cc] text-[14px] font-semibold inline-flex items-center space-x-1.5 border border-[#0066cc]/40 hover:border-[#0066cc] transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {action.icon && <span className="w-4 h-4 text-[#0066cc]">{action.icon}</span>}
                    <span>{text}</span>
                  </button>
                );
              })}

              {primaryAction && (() => {
                const clickHandler = primaryAction.onClick || primaryAction.onAction;
                const text = primaryAction.label || primaryAction.content;
                return (
                  <button
                    onClick={clickHandler}
                    disabled={primaryAction.disabled}
                    className="btn-primary min-h-[42px] px-5 text-white text-[14px] font-semibold inline-flex items-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                  >
                    {primaryAction.icon && <span className="w-4 h-4 stroke-[2.2]">{primaryAction.icon}</span>}
                    <span>{text}</span>
                  </button>
                );
              })()}
            </div>
          )}
        </div>

        {/* Content Region */}
        <div className="space-y-4">{children}</div>
      </div>
    </div>
  );
};
