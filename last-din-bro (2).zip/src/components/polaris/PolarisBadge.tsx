import React from 'react';

export type BadgeTone = 'success' | 'info' | 'neutral' | 'critical' | 'warning';

interface PolarisBadgeProps {
  children: React.ReactNode;
  tone?: BadgeTone;
  interactive?: boolean;
  onClick?: () => void;
  className?: string;
}

export const PolarisBadge: React.FC<PolarisBadgeProps> = ({
  children,
  tone = 'neutral',
  interactive = false,
  onClick,
  className = '',
}) => {
  const toneStyles: Record<BadgeTone, string> = {
    success: 'bg-[#e3f4e8] text-[#1e7b43]',
    info: 'bg-[#e8f0fe] text-[#0066cc]',
    neutral: 'bg-[#f5f5f7] text-[#1d1d1f] border border-[#e0e0e0]',
    critical: 'bg-[#fceaea] text-[#c62828]',
    warning: 'bg-[#fdeee7] text-[#c2410c]',
  };

  return (
    <span
      onClick={interactive ? onClick : undefined}
      className={`inline-flex items-center h-[22px] px-2.5 rounded-full text-[12px] font-semibold whitespace-nowrap transition-all ${
        toneStyles[tone]
      } ${interactive ? 'cursor-pointer hover:opacity-90 active:scale-95' : ''} ${className}`}
    >
      {children}
    </span>
  );
};
