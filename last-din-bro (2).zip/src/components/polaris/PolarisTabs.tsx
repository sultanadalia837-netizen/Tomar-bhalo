import React from 'react';

export interface TabItem<T extends string = string> {
  id: T;
  label: string;
  count?: number;
}

interface PolarisTabsProps<T extends string = string> {
  tabs: TabItem<T>[];
  selectedTab: T;
  onSelectTab: (tabId: T) => void;
  tools?: React.ReactNode;
}

export function PolarisTabs<T extends string = string>({
  tabs,
  selectedTab,
  onSelectTab,
  tools,
}: PolarisTabsProps<T>) {
  return (
    <div className="flex flex-col lg:flex-row lg:items-center justify-between px-4 py-3 border-b border-[#f0f0f0] gap-3 bg-white">
      {/* Filter Chips Row (Section 10.4 in design.md) */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 lg:pb-0 no-scrollbar" role="tablist">
        {tabs.map((tab) => {
          const isSelected = selectedTab === tab.id;
          return (
            <button
              key={tab.id}
              role="tab"
              aria-selected={isSelected}
              onClick={() => onSelectTab(tab.id)}
              className={`h-[38px] px-4 rounded-full text-[14px] flex items-center space-x-2 transition-all whitespace-nowrap cursor-pointer select-none ${
                isSelected
                  ? 'border-2 border-[#0071e3] bg-white text-[#1d1d1f] font-semibold shadow-xs'
                  : 'border border-[#e0e0e0] bg-white text-[#1d1d1f] hover:bg-[#f5f5f7] font-normal'
              }`}
            >
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span
                  className={`text-[12px] font-semibold tabular-nums px-2 py-0.5 rounded-full ${
                    isSelected ? 'bg-[#f5f5f7] text-[#1d1d1f]' : 'text-[#6e6e73]'
                  }`}
                >
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Right Tools Slot (Search, Sort, Filters) */}
      {tools && <div className="shrink-0 flex items-center space-x-2">{tools}</div>}
    </div>
  );
}
