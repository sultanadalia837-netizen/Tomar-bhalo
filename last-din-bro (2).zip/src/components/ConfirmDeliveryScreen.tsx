import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { PolarisCard } from './polaris/PolarisCard.tsx';
import { formatDate } from '../utils/logic.ts';
import { ArrowLeft, CheckCircle, AlertTriangle } from 'lucide-react';

interface ConfirmDeliveryScreenProps {
  orderNumber: number;
  category: 'Officer' | 'Airman';
  onNavigate: (screen: ScreenName, params?: any) => void;
  returnTo?: 'delivery' | 'orders' | 'order-details';
}

export const ConfirmDeliveryScreen: React.FC<ConfirmDeliveryScreenProps> = ({
  orderNumber,
  category,
  onNavigate,
  returnTo = 'delivery',
}) => {
  const { state, confirmOfficerDelivery, confirmAirmanDelivery } = useApp();

  const isOfficer = category === 'Officer';
  const officerOrder = isOfficer ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const airmanOrder = !isOfficer ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;
  const order = isOfficer ? officerOrder : airmanOrder;

  const todayStr = formatDate();

  // Form fields
  const [deliveredDate, setDeliveredDate] = useState<string>(todayStr);

  // Officer Financials
  const initialDiscount = isOfficer && officerOrder ? officerOrder.discountAmount || 0 : 0;
  const [discountInput, setDiscountInput] = useState<string>(String(initialDiscount));
  const [cashReceiveInput, setCashReceiveInput] = useState<string>('0');

  // Receiver Info
  const initialReceiverName = order ? order.customerName || '' : '';
  const initialReceiverPhone = order ? order.customerPhone || '' : '';
  const [receiverName, setReceiverName] = useState<string>(initialReceiverName);
  const [receiverPhone, setReceiverPhone] = useState<string>(initialReceiverPhone);

  const [formError, setFormError] = useState<string>('');

  if (!order) {
    return (
      <PolarisPage title="Order Not Found" backAction={() => onNavigate(returnTo)}>
        <PolarisCard>
          <div className="p-8 text-center text-[#616161]">
            <p className="text-sm">Order #{orderNumber} was not found.</p>
            <button
              onClick={() => onNavigate(returnTo)}
              className="mt-4 px-4 py-2 bg-[#303030] text-white rounded-lg text-xs font-semibold"
            >
              Back
            </button>
          </div>
        </PolarisCard>
      </PolarisPage>
    );
  }

  // Financial calculations for Officer
  const totalAmount = isOfficer && officerOrder ? officerOrder.totalAmount || 0 : 0;
  const advance = isOfficer && officerOrder ? officerOrder.advance || 0 : 0;
  const existingPayments = useMemo(
    () => (isOfficer && officerOrder?.payments ? officerOrder.payments : []),
    [isOfficer, officerOrder]
  );
  const alreadyReceivedLater = useMemo(
    () => existingPayments.reduce((sum, p) => sum + (Number(p.amount) || 0), 0),
    [existingPayments]
  );

  const discountAmount = useMemo(() => {
    const val = parseFloat(discountInput.replace(/,/g, ''));
    return isNaN(val) ? 0 : Math.max(0, val);
  }, [discountInput]);

  const cashReceiveAmount = useMemo(() => {
    const val = parseFloat(cashReceiveInput.replace(/,/g, ''));
    return isNaN(val) ? 0 : Math.max(0, val);
  }, [cashReceiveInput]);

  // Due before cash receive
  const dueBeforeCash = Math.max(0, totalAmount - discountAmount - advance - alreadyReceivedLater);
  // Live calculated Due
  const liveDue = Math.max(0, dueBeforeCash - cashReceiveAmount);

  // Validation
  const discountError = useMemo(() => {
    if (discountAmount < 0) return 'Discount cannot be negative.';
    if (discountAmount > totalAmount) return 'Discount cannot exceed Total Amount.';
    return '';
  }, [discountAmount, totalAmount]);

  const cashError = useMemo(() => {
    if (cashReceiveAmount < 0) return 'Cash Receive cannot be negative.';
    if (cashReceiveAmount > dueBeforeCash) return `Cash Receive cannot exceed due balance (৳${dueBeforeCash}).`;
    return '';
  }, [cashReceiveAmount, dueBeforeCash]);

  const handleCancel = () => {
    onNavigate(returnTo, { orderNumber, category });
  };

  const handleConfirm = () => {
    setFormError('');

    if (!deliveredDate) {
      setFormError('Please select a Delivered Date.');
      return;
    }

    if (isOfficer) {
      if (discountError) {
        setFormError(discountError);
        return;
      }
      if (cashError) {
        setFormError(cashError);
        return;
      }

      const res = confirmOfficerDelivery({
        orderNumber,
        deliveredDate,
        discountValue: String(discountAmount),
        discountType: 'taka',
        discountAmount,
        cashReceive: cashReceiveAmount,
        receiverName: receiverName.trim(),
        receiverPhone: receiverPhone.trim(),
      });

      if (!res.success) {
        setFormError(res.error || 'Failed to complete delivery.');
        return;
      }
    } else {
      const res = confirmAirmanDelivery({
        orderNumber,
        deliveredDate,
        receiverName: receiverName.trim(),
        receiverPhone: receiverPhone.trim(),
      });

      if (!res.success) {
        setFormError(res.error || 'Failed to complete delivery.');
        return;
      }
    }

    // Go back to the Delivery list (or caller screen)
    onNavigate(returnTo, { orderNumber, category, justDelivered: orderNumber });
  };

  return (
    <PolarisPage
      title="Confirm Delivery"
      subtitle={`Order #${order.orderNumber} · ${category}`}
      backAction={handleCancel}
    >
      <div className="max-w-2xl mx-auto space-y-4">
        {/* Green Banner: Marking as Delivered */}
        <div className="p-3.5 bg-[#EAFBE7] border border-[#BBE5B3] rounded-xl flex items-center space-x-2.5 text-[#0C5132]">
          <CheckCircle className="w-5 h-5 shrink-0 text-[#108043]" />
          <span className="text-xs sm:text-sm font-bold">Marking as Delivered</span>
        </div>

        {formError && (
          <div className="p-3 bg-[#FBEAE5] border border-[#FED3D1] rounded-xl flex items-center space-x-2 text-xs text-[#8E0B21] font-semibold">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>{formError}</span>
          </div>
        )}

        <PolarisCard>
          <div className="p-2 sm:p-4 space-y-4 text-xs">
            {/* 1. Delivered Date */}
            <div>
              <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">
                Delivered Date
              </label>
              <input
                type="date"
                value={deliveredDate}
                onChange={(e) => setDeliveredDate(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-lg text-xs font-mono font-medium text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
              />
            </div>

            {/* Officer Financial Fields */}
            {isOfficer && (
              <>
                {/* 2. Total Amount (Read-only) */}
                <div>
                  <label className="block text-xs font-semibold text-[#616161] mb-1">
                    Total Amount (৳)
                  </label>
                  <input
                    type="text"
                    readOnly
                    value={`৳${totalAmount}`}
                    className="w-full px-3 py-2 bg-[#F7F7F7] border border-[#E3E3E3] rounded-lg text-xs font-mono font-bold text-[#1A1A1A] cursor-not-allowed"
                  />
                </div>

                {/* 3. Discount (Editable) */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-xs font-semibold text-[#1A1A1A]">
                      Discount (৳)
                    </label>
                    {discountError && (
                      <span className="text-[11px] text-[#8E0B21] font-medium">{discountError}</span>
                    )}
                  </div>
                  <input
                    type="number"
                    min="0"
                    max={totalAmount}
                    value={discountInput}
                    onChange={(e) => setDiscountInput(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-lg text-xs font-mono font-bold text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
                  />
                </div>

                {/* 4. Advance (Read-only) */}
                <div>
                  <label className="block text-xs font-semibold text-[#616161] mb-1">
                    Advance (৳)
                  </label>
                  <input
                    type="text"
                    readOnly
                    value={`৳${advance}`}
                    className="w-full px-3 py-2 bg-[#F7F7F7] border border-[#E3E3E3] rounded-lg text-xs font-mono font-medium text-[#1A1A1A] cursor-not-allowed"
                  />
                </div>

                {/* 5. Already Received Later (Read-only, if any) */}
                {alreadyReceivedLater > 0 && (
                  <div>
                    <label className="block text-xs font-semibold text-[#616161] mb-1">
                      Already Received (৳)
                    </label>
                    <input
                      type="text"
                      readOnly
                      value={`৳${alreadyReceivedLater}`}
                      className="w-full px-3 py-2 bg-[#F7F7F7] border border-[#E3E3E3] rounded-lg text-xs font-mono font-medium text-[#1A1A1A] cursor-not-allowed"
                    />
                  </div>
                )}

                {/* 6. Cash Receive (Editable) */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-xs font-semibold text-[#1A1A1A]">
                      Cash Receive (৳)
                    </label>
                    {cashError && (
                      <span className="text-[11px] text-[#8E0B21] font-medium">{cashError}</span>
                    )}
                  </div>
                  <input
                    type="number"
                    min="0"
                    max={dueBeforeCash}
                    value={cashReceiveInput}
                    onChange={(e) => setCashReceiveInput(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-lg text-xs font-mono font-bold text-[#005BD3] focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
                  />
                  <span className="text-[11px] text-[#616161] mt-0.5 block">
                    Cash handed over by the customer right now
                  </span>
                </div>

                {/* 7. Due (Calculated) */}
                <div>
                  <label className="block text-xs font-semibold text-[#616161] mb-1">
                    Due (৳)
                  </label>
                  <div
                    className={`px-3 py-2 rounded-lg border font-mono font-extrabold text-sm ${
                      liveDue > 0
                        ? 'bg-[#FFF8F8] border-[#FED3D1] text-[#8E0B21]'
                        : 'bg-[#EAFBE7] border-[#BBE5B3] text-[#0C5132]'
                    }`}
                  >
                    ৳{liveDue}
                  </div>
                </div>
              </>
            )}

            {/* Receiver Name */}
            <div>
              <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">
                Receiver Name
              </label>
              <input
                type="text"
                value={receiverName}
                onChange={(e) => setReceiverName(e.target.value)}
                placeholder="Receiver name"
                className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-lg text-xs font-semibold text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
              />
            </div>

            {/* Receiver Phone Number */}
            <div>
              <label className="block text-xs font-semibold text-[#1A1A1A] mb-1">
                Receiver Phone Number
              </label>
              <input
                type="text"
                value={receiverPhone}
                onChange={(e) => setReceiverPhone(e.target.value)}
                placeholder="017XXXXXXXX"
                className="w-full px-3 py-2 bg-white border border-[#D1D5DB] rounded-lg text-xs text-[#1A1A1A] focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
              />
            </div>

            {/* Summary Box */}
            <div className="p-3 bg-[#FAFBFB] border border-[#E3E3E3] rounded-xl flex items-center justify-between font-semibold">
              <span className="text-[#0C5132] flex items-center space-x-1">
                <span>Status: ✓ Delivered</span>
              </span>
              {isOfficer && (
                <span className={liveDue > 0 ? 'text-[#8E0B21] font-bold font-mono' : 'text-[#0C5132] font-mono'}>
                  Due: ৳{liveDue}
                </span>
              )}
            </div>

            {/* Buttons */}
            <div className="pt-2 flex items-center justify-end space-x-3">
              <button
                type="button"
                onClick={handleCancel}
                className="px-4 py-2 bg-white border border-[#D1D5DB] hover:bg-[#F3F3F3] text-xs font-semibold text-[#303030] rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirm}
                className="px-5 py-2 bg-[#1A1A1A] hover:bg-black text-white text-xs font-bold rounded-xl shadow-xs cursor-pointer"
              >
                Confirm Delivery
              </button>
            </div>
          </div>
        </PolarisCard>
      </div>
    </PolarisPage>
  );
};
