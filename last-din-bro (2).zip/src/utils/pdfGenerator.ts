import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { NOTO_SANS_BENGALI_BASE64 } from './bengaliFont.ts';

/**
 * Initializes a new jsPDF document preconfigured with the offline
 * NotoSansBengali font, ensuring native rendering for English,
 * Bengali names, and the currency symbol '৳' (U+09F3).
 */
export function createPDFDoc(orientation: 'portrait' | 'landscape' = 'portrait'): jsPDF {
  const doc = new jsPDF({
    orientation,
    unit: 'pt',
    format: 'a4',
  });

  try {
    doc.addFileToVFS('NotoSansBengali-Regular.ttf', NOTO_SANS_BENGALI_BASE64);
    doc.addFont('NotoSansBengali-Regular.ttf', 'NotoSansBengali', 'normal');
    doc.setFont('NotoSansBengali');
  } catch (err) {
    console.warn('Failed to load embedded Bengali font, falling back to standard font', err);
  }

  return doc;
}

function addPDFHeader(doc: jsPDF, shopName: string, title: string, subtitle?: string): number {
  const pageWidth = doc.internal.pageSize.getWidth();

  doc.setFont('NotoSansBengali', 'normal');
  doc.setFontSize(16);
  doc.setTextColor(26, 26, 26);
  doc.text(shopName || 'Raymond Tailors & Outfitters', 40, 42);

  doc.setFontSize(12);
  doc.setTextColor(60, 60, 60);
  doc.text(title, 40, 62);

  if (subtitle) {
    doc.setFontSize(9);
    doc.setTextColor(110, 110, 110);
    doc.text(subtitle, 40, 78);
  }

  const dateStr = `Generated: ${new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })}`;
  doc.setFontSize(9);
  doc.setTextColor(110, 110, 110);
  doc.text(dateStr, pageWidth - 40, 42, { align: 'right' });

  const lineY = subtitle ? 88 : 72;
  doc.setDrawColor(215, 215, 215);
  doc.setLineWidth(0.75);
  doc.line(40, lineY, pageWidth - 40, lineY);

  return lineY + 16;
}

function addPDFFooter(doc: jsPDF) {
  const totalPages = doc.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('NotoSansBengali', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(140, 140, 140);
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - 40, pageHeight - 24, { align: 'right' });
    doc.text('Raymond Tailor Workshop Management System', 40, pageHeight - 24);
  }
}

// ---------------------------------------------------------------------------
// 1. DASHBOARD SUMMARY PDF
// ---------------------------------------------------------------------------
export interface DashboardPDFData {
  shopName: string;
  monthStr: string;
  totalActivePipeline: number;
  totalDeliveredCount: number;
  totalOutstandingDue: number;
  totalRevenueBilled: number;
  upcomingDeliveriesCount: number;
  cuttingSlipNeededCount: number;
  recentOrders: Array<{
    orderNumber: number;
    category: 'Officer' | 'Airman';
    customerName: string;
    customerBdNumber: string;
    status: string;
    totalAmount: number;
    due: number;
    orderDate: string;
  }>;
}

export function exportDashboardPDF(data: DashboardPDFData) {
  const doc = createPDFDoc('portrait');
  const startY = addPDFHeader(
    doc,
    data.shopName,
    'Workshop Dashboard & Operational Summary',
    `Period: ${data.monthStr || 'Current Month'} · Summary Snapshot`
  );

  // Key KPI Cards Table
  autoTable(doc, {
    startY,
    theme: 'grid',
    styles: { font: 'NotoSansBengali', fontSize: 10, cellPadding: 8 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255, halign: 'center', fontStyle: 'bold' },
    head: [['Active Pipeline', 'Delivered Orders', 'Revenue Billed', 'Outstanding Due']],
    body: [
      [
        `${data.totalActivePipeline} Orders`,
        `${data.totalDeliveredCount} Orders`,
        `৳${data.totalRevenueBilled.toLocaleString()}`,
        `৳${data.totalOutstandingDue.toLocaleString()}`,
      ],
    ],
    columnStyles: {
      0: { halign: 'center' },
      1: { halign: 'center' },
      2: { halign: 'center', textColor: [0, 91, 211] },
      3: { halign: 'center', textColor: [142, 11, 33] },
    },
  });

  const nextY = (doc as any).lastAutoTable.finalY + 18;

  doc.setFontSize(11);
  doc.setTextColor(30, 30, 30);
  doc.text('Recent Orders Overview', 40, nextY);

  const orderRows = data.recentOrders.map((o) => [
    `#${o.orderNumber}`,
    o.category,
    o.customerName || `Customer ${o.customerBdNumber}`,
    o.customerBdNumber,
    o.status,
    o.orderDate || '—',
    `৳${(Number(o.totalAmount) || 0).toLocaleString()}`,
    `৳${(Number(o.due) || 0).toLocaleString()}`,
  ]);

  autoTable(doc, {
    startY: nextY + 8,
    theme: 'striped',
    styles: { font: 'NotoSansBengali', fontSize: 9, cellPadding: 5 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    head: [['Order #', 'Type', 'Customer', 'BD #', 'Status', 'Date', 'Total', 'Due']],
    body: orderRows.length > 0 ? orderRows : [['—', '—', 'No recent orders', '—', '—', '—', '—', '—']],
    columnStyles: {
      0: { fontStyle: 'bold', halign: 'center' },
      1: { halign: 'center' },
      4: { halign: 'center' },
      5: { halign: 'center' },
      6: { halign: 'right' },
      7: { halign: 'right', textColor: [142, 11, 33] },
    },
  });

  addPDFFooter(doc);
  const fileName = `Dashboard-Report-${data.monthStr || new Date().toISOString().slice(0, 7)}.pdf`;
  doc.save(fileName);
}

// ---------------------------------------------------------------------------
// 2. STAFF SUMMARY PDF
// ---------------------------------------------------------------------------
export interface StaffSummaryRow {
  name: string;
  role: string;
  phone: string;
  totalWorks: number;
  totalAmount: number;
  totalKhoroch: number;
  netPayable: number;
  received: number;
  due: number;
  status: string;
}

export function exportStaffSummaryPDF(
  shopName: string,
  month: string,
  rows: StaffSummaryRow[]
) {
  const doc = createPDFDoc('landscape');
  const startY = addPDFHeader(
    doc,
    shopName,
    'Master Staff Hishab & Tailor Payroll Summary',
    `Month: ${month} · Staff Tailor Roster (${rows.length} Workers)`
  );

  const tableBody = rows.map((r, idx) => [
    idx + 1,
    r.name,
    r.role || 'Tailor',
    r.phone || '—',
    r.totalWorks,
    `৳${r.totalAmount.toLocaleString()}`,
    `৳${r.totalKhoroch.toLocaleString()}`,
    `৳${r.netPayable.toLocaleString()}`,
    `৳${r.received.toLocaleString()}`,
    `৳${r.due.toLocaleString()}`,
    r.status,
  ]);

  // Totals calculations
  const totalWorks = rows.reduce((s, r) => s + r.totalWorks, 0);
  const totalAmount = rows.reduce((s, r) => s + r.totalAmount, 0);
  const totalKhoroch = rows.reduce((s, r) => s + r.totalKhoroch, 0);
  const totalNet = rows.reduce((s, r) => s + r.netPayable, 0);
  const totalReceived = rows.reduce((s, r) => s + r.received, 0);
  const totalDue = rows.reduce((s, r) => s + r.due, 0);

  tableBody.push([
    '',
    'Total Summary',
    '',
    '',
    totalWorks,
    `৳${totalAmount.toLocaleString()}`,
    `৳${totalKhoroch.toLocaleString()}`,
    `৳${totalNet.toLocaleString()}`,
    `৳${totalReceived.toLocaleString()}`,
    `৳${totalDue.toLocaleString()}`,
    '',
  ]);

  autoTable(doc, {
    startY,
    theme: 'striped',
    styles: { font: 'NotoSansBengali', fontSize: 8.5, cellPadding: 5 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    head: [
      [
        '#',
        'Tailor Name',
        'Role',
        'Phone',
        'Items',
        'Gross Work',
        'Khoroch',
        'Net Payable',
        'Paid/Advance',
        'Due Balance',
        'Status',
      ],
    ],
    body: tableBody,
    columnStyles: {
      0: { halign: 'center', cellWidth: 24 },
      1: { fontStyle: 'bold' },
      4: { halign: 'center' },
      5: { halign: 'right' },
      6: { halign: 'right' },
      7: { halign: 'right', fontStyle: 'bold' },
      8: { halign: 'right' },
      9: { halign: 'right', fontStyle: 'bold', textColor: [142, 11, 33] },
      10: { halign: 'center' },
    },
    didParseCell: (data) => {
      // Bold the bottom totals row
      if (data.row.index === tableBody.length - 1) {
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.fillColor = [240, 240, 240];
      }
    },
  });

  addPDFFooter(doc);
  const fileName = `Staff-Summary-${month}.pdf`;
  doc.save(fileName);
}

// ---------------------------------------------------------------------------
// 3. WORKER MONTH STATEMENT PDF
// ---------------------------------------------------------------------------
export interface WorkerMonthPDFData {
  shopName: string;
  workerName: string;
  workerPhone?: string;
  workerRole?: string;
  month: string;
  hishab: {
    totalAmount: number;
    totalKhoroch: number;
    netPayable: number;
    received: number;
    due: number;
    status: string;
    worksCount: number;
  };
  entries: Array<{
    date: string;
    orderNumber: number;
    category: string;
    workItem: string;
    quantity: number;
    rate: number;
    lineTotal: number;
    notes?: string;
  }>;
  payments: Array<{
    date: string;
    amount: number;
    note?: string;
  }>;
}

export function exportWorkerMonthPDF(data: WorkerMonthPDFData) {
  const doc = createPDFDoc('portrait');
  const startY = addPDFHeader(
    doc,
    data.shopName,
    `Tailor Statement — ${data.workerName}`,
    `Month: ${data.month} · Role: ${data.workerRole || 'Tailor'} · Phone: ${data.workerPhone || '—'}`
  );

  // Financial Hishab Summary Card
  autoTable(doc, {
    startY,
    theme: 'grid',
    styles: { font: 'NotoSansBengali', fontSize: 9.5, cellPadding: 6 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255, halign: 'center' },
    head: [['Gross Work', 'Total Khoroch', 'Net Payable', 'Paid / Received', 'Due Balance', 'Status']],
    body: [
      [
        `৳${data.hishab.totalAmount.toLocaleString()}`,
        `৳${data.hishab.totalKhoroch.toLocaleString()}`,
        `৳${data.hishab.netPayable.toLocaleString()}`,
        `৳${data.hishab.received.toLocaleString()}`,
        `৳${data.hishab.due.toLocaleString()}`,
        data.hishab.status,
      ],
    ],
    columnStyles: {
      0: { halign: 'center' },
      1: { halign: 'center' },
      2: { halign: 'center', fontStyle: 'bold' },
      3: { halign: 'center' },
      4: { halign: 'center', fontStyle: 'bold', textColor: [142, 11, 33] },
      5: { halign: 'center', fontStyle: 'bold' },
    },
  });

  let currentY = (doc as any).lastAutoTable.finalY + 16;

  // Work Item Entries Table
  doc.setFontSize(11);
  doc.setTextColor(30, 30, 30);
  doc.text(`Work Items Completed (${data.entries.length})`, 40, currentY);

  const entryRows = data.entries.map((e, idx) => [
    idx + 1,
    e.date,
    `#${e.orderNumber}`,
    e.category,
    e.workItem,
    e.quantity,
    `৳${e.rate}`,
    `৳${e.lineTotal}`,
    e.notes || '—',
  ]);

  autoTable(doc, {
    startY: currentY + 6,
    theme: 'striped',
    styles: { font: 'NotoSansBengali', fontSize: 8.5, cellPadding: 4 },
    headStyles: { fillColor: [70, 70, 70], textColor: 255 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    head: [['#', 'Date', 'Order #', 'Type', 'Work Item', 'Qty', 'Rate', 'Total', 'Notes']],
    body: entryRows.length > 0 ? entryRows : [['—', '—', '—', '—', 'No work items recorded', '—', '—', '—', '—']],
    columnStyles: {
      0: { halign: 'center', cellWidth: 20 },
      1: { halign: 'center' },
      2: { halign: 'center', fontStyle: 'bold' },
      3: { halign: 'center' },
      5: { halign: 'center' },
      6: { halign: 'right' },
      7: { halign: 'right', fontStyle: 'bold' },
    },
  });

  currentY = (doc as any).lastAutoTable.finalY + 16;

  // Payments / Khoroch Table
  doc.setFontSize(11);
  doc.setTextColor(30, 30, 30);
  doc.text(`Payments & Advance Received (${data.payments.length})`, 40, currentY);

  const paymentRows = data.payments.map((p, idx) => [
    idx + 1,
    p.date,
    `৳${(Number(p.amount) || 0).toLocaleString()}`,
    p.note || 'Cash payment',
  ]);

  autoTable(doc, {
    startY: currentY + 6,
    theme: 'striped',
    styles: { font: 'NotoSansBengali', fontSize: 8.5, cellPadding: 4 },
    headStyles: { fillColor: [70, 70, 70], textColor: 255 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    head: [['#', 'Payment Date', 'Amount', 'Payment Note']],
    body: paymentRows.length > 0 ? paymentRows : [['—', '—', '৳0', 'No payment records for this month']],
    columnStyles: {
      0: { halign: 'center', cellWidth: 20 },
      1: { halign: 'center' },
      2: { halign: 'right', fontStyle: 'bold', textColor: [0, 91, 211] },
    },
  });

  addPDFFooter(doc);
  const cleanName = data.workerName.replace(/\s+/g, '_');
  const fileName = `Worker-Statement-${cleanName}-${data.month}.pdf`;
  doc.save(fileName);
}

// ---------------------------------------------------------------------------
// 4. WORKER PAYSLIP PDF
// ---------------------------------------------------------------------------
export interface PayslipPDFData {
  shopName: string;
  workerName: string;
  workerPhone?: string;
  workerRole?: string;
  month: string;
  hishab: {
    totalAmount: number;
    totalKhoroch: number;
    netPayable: number;
    received: number;
    due: number;
    status: string;
    worksCount: number;
  };
}

export function exportWorkerPayslipPDF(data: PayslipPDFData) {
  const doc = createPDFDoc('portrait');
  const startY = addPDFHeader(
    doc,
    data.shopName,
    'Official Monthly Tailor Payslip',
    `Month: ${data.month} · Salary & Work Hishab Voucher`
  );

  // Payslip Receipt Container
  const pageWidth = doc.internal.pageSize.getWidth();
  const boxX = 40;
  const boxWidth = pageWidth - 80;

  // Tailor Metadata Box
  autoTable(doc, {
    startY,
    theme: 'plain',
    styles: { font: 'NotoSansBengali', fontSize: 10, cellPadding: 3 },
    body: [
      ['Tailor Name:', data.workerName, 'Month:', data.month],
      ['Designation:', data.workerRole || 'Master Tailor', 'Payment Date:', new Date().toISOString().slice(0, 10)],
      ['Phone:', data.workerPhone || '—', 'Status:', data.hishab.status],
    ],
    columnStyles: {
      0: { fontStyle: 'bold', textColor: [100, 100, 100], cellWidth: 90 },
      1: { fontStyle: 'bold', textColor: [20, 20, 20] },
      2: { fontStyle: 'bold', textColor: [100, 100, 100], cellWidth: 80 },
      3: { textColor: [20, 20, 20] },
    },
  });

  const nextY = (doc as any).lastAutoTable.finalY + 12;

  // Financial Breakdown Line Items Table
  autoTable(doc, {
    startY: nextY,
    theme: 'grid',
    styles: { font: 'NotoSansBengali', fontSize: 10, cellPadding: 8 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255 },
    head: [['Earnings & Deductions Item', 'Amount (৳)']],
    body: [
      [`Total Completed Work Earnings (${data.hishab.worksCount} items)`, `৳${data.hishab.totalAmount.toLocaleString()}`],
      ['Less: Workshop Deductions / Khoroch', `-৳${data.hishab.totalKhoroch.toLocaleString()}`],
      ['Net Payable Earnings', `৳${data.hishab.netPayable.toLocaleString()}`],
      ['Less: Advance / Cash Received So Far', `-৳${data.hishab.received.toLocaleString()}`],
      ['Remaining Balance Due', `৳${data.hishab.due.toLocaleString()}`],
    ],
    columnStyles: {
      0: { fontStyle: 'normal' },
      1: { halign: 'right', fontStyle: 'bold' },
    },
    didParseCell: (dataCell) => {
      if (dataCell.row.index === 2) {
        dataCell.cell.styles.fillColor = [240, 246, 255];
        dataCell.cell.styles.fontStyle = 'bold';
      }
      if (dataCell.row.index === 4) {
        dataCell.cell.styles.fillColor = [254, 233, 232];
        dataCell.cell.styles.textColor = [142, 11, 33];
        dataCell.cell.styles.fontStyle = 'bold';
      }
    },
  });

  const signY = (doc as any).lastAutoTable.finalY + 65;

  // Signatures
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.75);

  doc.line(60, signY, 200, signY);
  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);
  doc.text('Tailor / Receiver Signature', 75, signY + 14);

  doc.line(pageWidth - 200, signY, pageWidth - 60, signY);
  doc.text('Authorized Workshop Signature', pageWidth - 190, signY + 14);

  addPDFFooter(doc);
  const cleanName = data.workerName.replace(/\s+/g, '_');
  const fileName = `Payslip-${cleanName}-${data.month}.pdf`;
  doc.save(fileName);
}

// ---------------------------------------------------------------------------
// 5. OFFICIAL RAYMOND CUSTOMER DELIVERY INVOICE PDF
// Inspired by screenshot: Burgundy #5C1221 Header, Gold Accents, Huge Order ID
// ---------------------------------------------------------------------------
export function exportCustomerInvoicePDF(order: any, shopSettings?: any) {
  const doc = createPDFDoc('portrait');
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  const shopName = shopSettings?.invoiceShopName || 'ONE RAYMOND TAILORS & FABRICS';
  const shopPhone = shopSettings?.invoiceShopPhone || '01784161522 / 01333255692';
  const shopAddress = shopSettings?.invoiceShopAddress || 'Base tailor shop, BAF base bashar, Dhaka cant 1206';

  // 1. Deep Burgundy Header Banner (#5C1221)
  doc.setFillColor(92, 18, 33);
  doc.rect(0, 0, pageWidth, 74, 'F');

  // Gold Trim Line (#D4AF37)
  doc.setFillColor(212, 175, 55);
  doc.rect(0, 74, pageWidth, 3.5, 'F');

  // Header Left: Shop Name & Contacts
  doc.setFont('NotoSansBengali', 'normal');
  doc.setFontSize(14);
  doc.setTextColor(255, 255, 255);
  doc.text(shopName.toUpperCase(), 36, 34);

  doc.setFontSize(8.5);
  doc.setTextColor(245, 208, 115); // soft gold
  doc.text(`Phone: ${shopPhone}  ·  BAF Base Bashar`, 36, 52);

  // Header Right: DELIVERY INVOICE & HUGE ORDER NUMBER
  doc.setFontSize(9);
  doc.setTextColor(245, 208, 115);
  doc.text('DELIVERY INVOICE', pageWidth - 36, 28, { align: 'right' });

  // HUGE Order ID (Biggest element)
  doc.setFontSize(26);
  doc.setTextColor(255, 255, 255);
  doc.text(`#${order.orderNumber}`, pageWidth - 36, 58, { align: 'right' });

  let currentY = 96;

  // 2. Customer Metadata Card & Order Dates
  // Left: Bill To Box
  doc.setFillColor(250, 250, 252);
  doc.setDrawColor(225, 228, 234);
  doc.roundedRect(36, currentY, 280, 72, 6, 6, 'FD');

  doc.setFillColor(92, 18, 33);
  doc.roundedRect(36, currentY, 80, 18, 4, 4, 'F');
  doc.setFontSize(8.5);
  doc.setTextColor(255, 255, 255);
  doc.text('BILL TO', 46, currentY + 12);

  doc.setFontSize(12);
  doc.setTextColor(20, 20, 20);
  doc.text(order.customerName || 'Customer', 46, currentY + 36);

  doc.setFontSize(8.5);
  doc.setTextColor(100, 100, 100);
  doc.text('BD NUMBER:', 46, currentY + 50);
  doc.setFontSize(9.5);
  doc.setTextColor(92, 18, 33);
  doc.text(order.customerBdNumber || '—', 110, currentY + 50);

  if (order.customerPhone) {
    doc.setFontSize(8.5);
    doc.setTextColor(80, 80, 80);
    doc.text(`Phone: ${order.customerPhone}`, 46, currentY + 63);
  }

  // Right: Order Date & Delivery Date Box
  doc.setFillColor(250, 250, 252);
  doc.setDrawColor(225, 228, 234);
  doc.roundedRect(326, currentY, pageWidth - 362, 72, 6, 6, 'FD');

  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text('ORDER DATE', 338, currentY + 20);
  doc.setFontSize(10);
  doc.setTextColor(30, 30, 30);
  doc.text(order.orderDate || '—', 338, currentY + 33);

  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text('DELIVERY DATE', 338, currentY + 50);
  doc.setFontSize(10);
  if (order.status === 'Delivered') {
    doc.setTextColor(22, 101, 52);
  } else {
    doc.setTextColor(92, 18, 33);
  }
  doc.text(order.deliveryDate || '—', 338, currentY + 63);

  currentY += 86;

  // 3. Items Table with Burgundy Header
  const tableRows = (order.items || []).map((item: any, idx: number) => [
    idx + 1,
    item.name,
    item.quantity || 1,
    `BDT ${(Number(item.price) || 0).toLocaleString()}`,
    `BDT ${(Number(item.lineTotal) || 0).toLocaleString()}`,
  ]);

  autoTable(doc, {
    startY: currentY,
    theme: 'plain',
    styles: { font: 'NotoSansBengali', fontSize: 9, cellPadding: 7 },
    headStyles: {
      fillColor: [92, 18, 33],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'left',
    },
    alternateRowStyles: { fillColor: [250, 250, 252] },
    head: [['#', 'ITEM NAME', 'QTY', 'UNIT PRICE', 'TOTAL AMOUNT']],
    body: tableRows.length > 0 ? tableRows : [['1', 'Bespoke Tailoring Item', '1', 'BDT 0', 'BDT 0']],
    columnStyles: {
      0: { halign: 'center', cellWidth: 26 },
      1: { fontStyle: 'bold' },
      2: { halign: 'center', cellWidth: 44 },
      3: { halign: 'right', cellWidth: 84 },
      4: { halign: 'right', cellWidth: 94, fontStyle: 'bold' },
    },
  });

  const tableBottomY = (doc as any).lastAutoTable.finalY + 12;

  // 4. Financial Calculation Summary Block
  const summaryBoxWidth = 240;
  const summaryBoxX = pageWidth - 36 - summaryBoxWidth;

  const totalAmount = Number(order.totalAmount) || 0;
  const advance = Number(order.advance) || 0;
  const discount = Number(order.discountAmount) || 0;
  const due = Number(order.due) || 0;

  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);

  let finY = tableBottomY + 10;
  doc.text('Subtotal:', summaryBoxX, finY);
  doc.setFontSize(9.5);
  doc.setTextColor(20, 20, 20);
  doc.text(`BDT ${totalAmount.toLocaleString()}`, pageWidth - 36, finY, { align: 'right' });

  if (discount > 0) {
    finY += 16;
    doc.setFontSize(9);
    doc.setTextColor(80, 80, 80);
    doc.text('Discount:', summaryBoxX, finY);
    doc.setTextColor(22, 101, 52);
    doc.text(`- BDT ${discount.toLocaleString()}`, pageWidth - 36, finY, { align: 'right' });
  }

  finY += 16;
  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);
  doc.text('Advance Paid:', summaryBoxX, finY);
  doc.setTextColor(22, 101, 52);
  doc.text(`- BDT ${advance.toLocaleString()}`, pageWidth - 36, finY, { align: 'right' });

  finY += 14;

  // 5. GOLD / AMBER DUE BANNER (matching reference #E5A824)
  const bannerY = finY;
  doc.setFillColor(229, 168, 36);
  doc.roundedRect(summaryBoxX - 10, bannerY, summaryBoxWidth + 10, 28, 4, 4, 'F');

  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text('DUE BALANCE', summaryBoxX + 6, bannerY + 18);

  doc.setFontSize(13);
  doc.text(`BDT ${due.toLocaleString()}`, pageWidth - 42, bannerY + 18, { align: 'right' });

  // 6. Footer and Cut Stub
  const footerY = pageHeight - 54;

  // Dashed Cut Line
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.75);
  doc.setLineDashPattern([4, 4], 0);
  doc.line(36, footerY - 14, pageWidth - 36, footerY - 14);
  doc.setLineDashPattern([], 0); // reset

  doc.setFontSize(7.5);
  doc.setTextColor(130, 130, 130);
  doc.text('✂ - - - - - - - - - - - - - - - - - Cut Here - - - - - - - - - - - - - - - - - ✂', pageWidth / 2, footerY - 8, {
    align: 'center',
  });

  // Burgundy bottom strip
  doc.setFillColor(92, 18, 33);
  doc.rect(0, footerY, pageWidth, 54, 'F');

  doc.setFontSize(8);
  doc.setTextColor(245, 208, 115);
  doc.text('Quality Tailoring  |  Timely Delivery  |  Customer Satisfaction', pageWidth / 2, footerY + 18, {
    align: 'center',
  });

  doc.setFontSize(7.5);
  doc.setTextColor(255, 255, 255);
  doc.text(`Address: ${shopAddress}`, pageWidth / 2, footerY + 34, { align: 'center' });

  const fileName = `Invoice-Customer-${order.orderNumber}-${order.customerBdNumber || 'order'}.pdf`;
  doc.save(fileName);
}

// ---------------------------------------------------------------------------
// 6. OFFICIAL RAYMOND WORKSHOP SHOP RECORD INVOICE PDF
// Master copy kept in tailor workshop records with measurements breakdown
// ---------------------------------------------------------------------------
export function exportShopRecordInvoicePDF(order: any, shopSettings?: any) {
  const doc = createPDFDoc('portrait');
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  const shopName = shopSettings?.invoiceShopName || 'ONE RAYMOND TAILORS & FABRICS';
  const shopPhone = shopSettings?.invoiceShopPhone || '01784161522 / 01333255692';

  // 1. Deep Burgundy Header Banner (#5C1221)
  doc.setFillColor(92, 18, 33);
  doc.rect(0, 0, pageWidth, 74, 'F');

  // Gold Trim Line (#D4AF37)
  doc.setFillColor(212, 175, 55);
  doc.rect(0, 74, pageWidth, 3.5, 'F');

  // Header Left
  doc.setFont('NotoSansBengali', 'normal');
  doc.setFontSize(14);
  doc.setTextColor(255, 255, 255);
  doc.text(shopName.toUpperCase(), 36, 34);

  doc.setFontSize(8.5);
  doc.setTextColor(245, 208, 115);
  doc.text(`WORKSHOP RECORD  ·  Shop Master Copy  ·  ${shopPhone}`, 36, 52);

  // Header Right: ORDER RECORD & HUGE ORDER NUMBER
  doc.setFontSize(9);
  doc.setTextColor(245, 208, 115);
  doc.text('SHOP RECORD INVOICE', pageWidth - 36, 28, { align: 'right' });

  doc.setFontSize(26);
  doc.setTextColor(255, 255, 255);
  doc.text(`#${order.orderNumber}`, pageWidth - 36, 58, { align: 'right' });

  let currentY = 94;

  // 2. Metadata Box
  doc.setFillColor(250, 250, 252);
  doc.setDrawColor(225, 228, 234);
  doc.roundedRect(36, currentY, pageWidth - 72, 60, 6, 6, 'FD');

  doc.setFontSize(11);
  doc.setTextColor(20, 20, 20);
  doc.text(`Customer: ${order.customerName || '—'}`, 48, currentY + 22);

  doc.setFontSize(9);
  doc.setTextColor(100, 100, 100);
  doc.text(`BD Number: ${order.customerBdNumber || '—'}`, 48, currentY + 38);
  doc.text(`Branch: ${order.branch || 'General'}`, 200, currentY + 38);
  doc.text(`Ribbon: ${order.ribbon ? `R-${order.ribbon}` : 'None'}`, 320, currentY + 38);

  doc.text(`Order Date: ${order.orderDate || '—'}`, 48, currentY + 52);
  doc.text(`Delivery Date: ${order.deliveryDate || '—'}`, 200, currentY + 52);
  doc.text(`Status: ${order.status || 'Pending'}`, 320, currentY + 52);

  currentY += 72;

  // 3. Tailor Measurements Breakdown Matrix
  const s = order.shirtMeasurements || {};
  const p = order.pantMeasurements || {};

  autoTable(doc, {
    startY: currentY,
    theme: 'grid',
    styles: { font: 'NotoSansBengali', fontSize: 8.5, cellPadding: 5 },
    headStyles: { fillColor: [40, 40, 40], textColor: 255 },
    head: [['Garment', 'Key Tailoring Measurements (Inches)', 'Special Tailor Cutting Notes']],
    body: [
      [
        'Shirt / Upper',
        `Length: ${s.length || '—'} · Chest: ${s.chest || '—'} · Belly: ${s.belly || '—'} · Shoulder: ${s.shoulder || '—'} · Sleeve: ${s.sleeve || '—'} · Collar: ${s.collar || '—'} · Front: ${s.front || '—'}`,
        [s.handWrittenNotes, s.extraNotes].filter(Boolean).join(' | ') || 'Standard cut',
      ],
      [
        'Pant / Lower',
        `Length: ${p.length || '—'} · Waist: ${p.waist || '—'} · Hip: ${p.hip || '—'} · High: ${p.high || '—'} · Thai: ${p.thai || '—'} · Leg Open: ${p.legOpen || '—'}`,
        [p.handWrittenNotes, p.extraNotes].filter(Boolean).join(' | ') || 'Standard cut',
      ],
    ],
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 80 },
      1: { cellWidth: 260 },
      2: { fontStyle: 'italic' },
    },
  });

  currentY = (doc as any).lastAutoTable.finalY + 12;

  // 4. Ordered Items Table
  const tableRows = (order.items || []).map((item: any, idx: number) => [
    idx + 1,
    item.name,
    item.quantity || 1,
    `BDT ${(Number(item.price) || 0).toLocaleString()}`,
    `BDT ${(Number(item.lineTotal) || 0).toLocaleString()}`,
  ]);

  autoTable(doc, {
    startY: currentY,
    theme: 'plain',
    styles: { font: 'NotoSansBengali', fontSize: 8.5, cellPadding: 5 },
    headStyles: { fillColor: [92, 18, 33], textColor: [255, 255, 255], fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [250, 250, 252] },
    head: [['#', 'ITEM NAME', 'QTY', 'PRICE', 'LINE TOTAL']],
    body: tableRows.length > 0 ? tableRows : [['1', 'Standard Item', '1', 'BDT 0', 'BDT 0']],
    columnStyles: {
      0: { halign: 'center', cellWidth: 24 },
      2: { halign: 'center', cellWidth: 40 },
      3: { halign: 'right', cellWidth: 70 },
      4: { halign: 'right', cellWidth: 80, fontStyle: 'bold' },
    },
  });

  const finY = (doc as any).lastAutoTable.finalY + 10;
  const totalAmount = Number(order.totalAmount) || 0;
  const advance = Number(order.advance) || 0;
  const due = Number(order.due) || 0;

  // Summary box
  doc.setFontSize(9);
  doc.setTextColor(50, 50, 50);
  doc.text(`Total Billed: BDT ${totalAmount.toLocaleString()}   ·   Advance: BDT ${advance.toLocaleString()}   ·   Balance Due: BDT ${due.toLocaleString()}`, 36, finY + 10);

  // Workshop Sign-Off Block
  const signY = pageHeight - 90;
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.75);

  doc.line(40, signY, 180, signY);
  doc.setFontSize(8.5);
  doc.setTextColor(90, 90, 90);
  doc.text('Cutter Master Signature', 55, signY + 12);

  doc.line(pageWidth - 180, signY, pageWidth - 40, signY);
  doc.text('Workshop Manager Approval', pageWidth - 165, signY + 12);

  addPDFFooter(doc);
  const fileName = `Shop-Record-#${order.orderNumber}-${order.customerBdNumber || 'order'}.pdf`;
  doc.save(fileName);
}
