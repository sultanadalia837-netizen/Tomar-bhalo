export type OrderStatus = 'Pending' | 'Cutting Slip – Done' | 'Delivered';
export type OrderCategory = 'Officer' | 'Airman';
export type DiscountType = 'percentage' | 'taka';
export type PaperSize = 'A4' | 'A5';

export interface ShirtMeasurements {
  length: string;
  chest: string;
  belly: string;
  hip: string;
  shoulder: string;
  sleeve: string;
  collar: string;
  front: string;
  back: string;
  handWrittenNotes: string;
  extraNotes: string;
}

export interface PantMeasurements {
  length: string;
  waist: string;
  hip: string;
  high: string;
  thai: string;
  legOpen: string;
  handWrittenNotes: string;
  extraNotes: string;
}

export interface OfficerOrderItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  lineTotal: number;
}

export interface AirmanOrderItem {
  id: string;
  name: string;
  quantity: number;
  ivNumber: string;
}

export interface PaymentRecord {
  id: string;
  amount: number;
  date: string; // YYYY-MM-DD
}

export type SlipType = 'Shirt' | 'Pant' | 'Shirt + Pant';

export interface OfficerOrder {
  id: string;
  orderNumber: number;
  category: 'Officer';
  customerBdNumber: string;
  customerName: string;
  customerPhone: string;
  branch?: string; // GDP, NON-GDP, HALF WING
  orderDate: string; // YYYY-MM-DD
  deliveryDate: string; // YYYY-MM-DD
  deliveredDate?: string; // YYYY-MM-DD
  receiverName?: string;
  receiverPhone?: string;
  ribbon: string;
  status: OrderStatus;
  items: OfficerOrderItem[];
  shirtMeasurements: ShirtMeasurements;
  pantMeasurements: PantMeasurements;
  totalAmount: number;
  discountValue: string;
  discountType: DiscountType;
  discountAmount: number;
  advance: number;
  payments: PaymentRecord[];
  due: number;
  createdAt: string;
  updatedAt: string;
}

export interface AirmanOrder {
  id: string;
  orderNumber: number;
  category: 'Airman';
  customerBdNumber: string;
  customerName: string;
  customerPhone: string;
  orderDate: string; // YYYY-MM-DD
  deliveredDate?: string; // YYYY-MM-DD
  receiverName?: string;
  receiverPhone?: string;
  trade?: string;
  ribbon: string;
  office?: string;
  runningYear: string;
  status: OrderStatus;
  items: AirmanOrderItem[];
  shirtMeasurements: ShirtMeasurements;
  pantMeasurements: PantMeasurements;
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  category: OrderCategory;
  bdNumber: string;
  name: string;
  phone: string;
  createdAt: string;
}

export interface Draft {
  id: string;
  category: OrderCategory;
  lastSaved: string; // ISO string
  customerBdNumber: string;
  customerName: string;
  customerPhone: string;
  branch?: string;
  orderDate: string;
  deliveryDate: string;
  ribbon: string;
  trade?: string;
  office?: string;
  runningYear?: string;
  officerItems?: OfficerOrderItem[];
  airmanItems?: AirmanOrderItem[];
  officerEditingRow?: any;
  airmanEditingRow?: any;
  shirtMeasurements: ShirtMeasurements;
  pantMeasurements: PantMeasurements;
  discountValue?: string;
  discountType?: DiscountType;
  advance?: number;
  totalAmount?: number;
}

export interface ItemDefinition {
  id: string;
  name: string;
  price: number;
  category?: string;
  needsPriceCheck?: boolean;
  slipType?: SlipType;
}

export interface AirmanItemDefinition {
  id: string;
  name: string;
  slipType?: SlipType;
}

export interface WorkItemDefinition {
  id: string;
  name: string;
  rate: number;
  flaggedCheck?: boolean;
}

export interface StaffWorker {
  id: string;
  serialNumber: number;
  name: string; // English, unique
  banglaName: string;
  active: boolean;
  createdAt: string;
}

export interface WorkerEntryRow {
  id: string;
  workerId: string;
  date: string; // YYYY-MM-DD
  serial: string; // order number
  category?: OrderCategory;
  bdNumber: string;
  name: string;
  item: string;
  quantity: number;
  unitPrice: number;
  totalTaka: number;
  khorochDate: string;
  khoroch: number;
  note?: string;
}

export interface WorkerPayment {
  id: string;
  workerId: string;
  forMonth: string; // YYYY-MM
  amount: number;
  date: string; // YYYY-MM-DD
  note: string;
  createdAt: string;
}

export interface DeletedOfficerOrder {
  order: OfficerOrder;
  deletedAt: string;
}

export interface DeletedAirmanOrder {
  order: AirmanOrder;
  deletedAt: string;
}

export interface ShopSettings {
  items: ItemDefinition[];
  airmanItems: AirmanItemDefinition[];
  workItems: WorkItemDefinition[];
  branchValues: string[];
  ribbonValues: string[];
  tradeValues: string[];
  officeValues: string[];
  runningYears: string[];
  defaultDiscountType: DiscountType;
  upcomingDeliveryDays: number;
  invoiceShopName: string;
  invoiceShopAddress?: string;
  invoiceShopPhone?: string;
  invoiceLogo: string;
  invoiceTerms: string;
  invoicePaperSize: PaperSize;
  cuttingSlipPaperSize: PaperSize;
}

export interface AppState {
  officerOrders: OfficerOrder[];
  airmanOrders: AirmanOrder[];
  deletedOfficerOrders: DeletedOfficerOrder[];
  deletedAirmanOrders: DeletedAirmanOrder[];
  customers: Customer[];
  drafts: Draft[];
  workers: StaffWorker[];
  workerRows: WorkerEntryRow[];
  workerPayments: WorkerPayment[];
  settings: ShopSettings;
}
