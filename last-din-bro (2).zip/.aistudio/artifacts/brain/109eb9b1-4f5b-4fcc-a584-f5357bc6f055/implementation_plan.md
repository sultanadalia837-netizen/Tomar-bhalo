# Raymond — Tailor Shop Management System: Executive UI/UX & Mobile Revamp

A comprehensive revamp of the Raymond bespoke tailoring management platform for Bangladesh Air Force Officer and Airman uniforms, introducing high-contrast executive aesthetics, Apple-style frosted glass touches, a 3-per-line Big Box order grid (responsive 1-per-line on mobile), streamlined horizontal item/quantity selectors, and an intelligent executive dashboard.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences and brand specifications have been incorporated directly into this architectural plan:
> - **Brand Identity**: Strictly **Raymond** (pure brand name without extra tags, AI badges, or mechanical clutter).
> - **Navigation Hierarchy**: Default initial screen is **Orders** (`officer-orders`). The overview view is explicitly **Dashboard** (`dashboard`), completely eliminating any ambiguous "Home" page.
> - **Order Grid Architecture**: Default **Big Box Grid** layout displaying **3 cards per row on desktop** (forming a balanced 6-box view in 2 rows) and **1 card per row on mobile**, with quick toggle to the high-density table view.
> - **Item & Quantity Interaction**: Minimalist horizontal-scrollable row of uniform categories/items with inline tactile count steppers (`-` / `+`), removing screen-switching disruptions.
> - **Dashboard Visuals**: Faithful translation of the provided reference design (`Home@1x (1).png`) featuring the dark "Due after delivery" hero card with progress bar, quick delivery list, status pipeline, and 3-card "Needs attention" priority section with instant payment action.
> - **Mobile Responsiveness**: Complete touch-first responsiveness with bottom thumb navigation, smooth gesture-friendly drawers, and full-width card layouts.

---

## 1. Overview & Core Concept

### What It Does
Raymond is an operational workbench tailored specifically for Bangladesh Air Force (BAF) Officer and Airman uniform tailoring. It coordinates measurement records, cutting slips, delivery pipelines, customer history by BD number, staff payroll ledger (karigor hishab), and real-time cashflow collections with zero latency.

### Target Audience & Persona
- **Shop Master / Cashier**: Rapid order creation, instant BD number auto-lookup, issuing cutting slips, taking partial advances, and collecting delivery dues.
- **Master Tailor & Cutting Staff**: Clear, printable cutting slip specifications, fabric allowance measurements, and worker line item assignments.
- **Owner / Manager**: High-level financial clarity via the Dashboard, tracking weekly cashflow collections, overdue deliverables, and karigor balances.

### Key Value Delivered
Eliminates fragmented workflows and clunky multi-step dialogs by providing immediate inline item selection, Apple-level micro-interactions, responsive mobile access for on-the-floor tailoring status checks, and a crisp high-contrast layout.

---

## 2. User Experience & Visual Design

### Visual Identity & Theme
- **Aesthetic Direction**: Executive Bespoke Workbench — pairing Shopify Polaris functional clarity with Apple macOS frosted glass depth (`backdrop-blur-md`, subtle hairline borders, and deep charcoal anchors).
- **Color Palette & Distribution (60-30-10 Rule)**:
  - **60% Dominant Canvas**: Clean off-white canvas (`#F4F5F7` / `#F8F9FA`) and crisp white card faces (`#FFFFFF`).
  - **30% Structural Depth**: Deep charcoal top chrome (`#1A1A1A`), dark executive hero cards (`#14171A` to `#1E2328`), and hairline perimeter borders (`#E5E7EB`).
  - **10% High-Intent Contrast Accents**:
    - Royal Tailoring Blue (`#005BD3` / `#0969DA`) for active tabs, primary action buttons, and BD numbers.
    - Crimson Alert (`#DC2626` / `#8E0B21`) for overdue deliveries and outstanding due amounts.
    - Forest Success (`#0C5132` / `#16A34A`) for 100% paid badges and delivery confirmations.
    - Amber Priority (`#B45309` / `#D97706`) for cutting slip pending status.
- **Typography & Hierarchy**:
  - Primary UI & Display: Variable Inter / Plus Jakarta Sans (`tracking-tight`, semibold 600–700 headlines, 13px base body).
  - Financial & Telemetry: Monospace tabular numerals (`tabular-nums font-mono`) for currency (৳), BD numbers, dates, and measurement values.

### Key User Flows

#### Flow 1: Big Box Order Exploration & Status Action
1. User opens Raymond $\rightarrow$ lands directly on **Orders** (`officer-orders`).
2. Order cards render in a **3-column desktop grid** (1-column on mobile).
3. Each big card features:
   - Top black badge `#530` + Officer Name + BD Number (`BD/9163`) + Branch.
   - Status badge (`Cutting Slip – Done`, `Pending`, etc.) + Overdue indicator if applicable.
   - Clean order and delivery dates with clear typography.
   - Financial breakdown: Total ৳, Advance ৳, and Due ৳ with an inline progress fill bar.
   - Primary action button: `Pay ৳X,XXX` (if due) or `View Cutting Slip` / `Mark Delivered`.
4. Quick toggle button in header allows switching between **Big Box Grid** and **Compact Table View**.

#### Flow 2: Effortless Uniform Item & Quantity Selection
1. In New/Edit Order, user arrives at **Order Items**.
2. Items are displayed in a clean, horizontal scrollable row of styled uniform item chips (e.g. `SD Service Dress`, `Combat / Battle Uniform`, `Working Dress`, `Safari`, `Trouser`, `Ribbon`).
3. Tapping an item adds or selects it immediately.
4. Each selected item row features a minimalist **inline count stepper** (`-` `[ 1 ]` `+`) with direct tap buttons—no modal popups or screen transitions.
5. Unit price and line total update instantly with real-time recalculation of total and discount.

#### Flow 3: Executive Dashboard & Delivery Insights
1. User taps **Dashboard** in navigation.
2. Animated greeting: "Good morning / afternoon. [X] orders are upcoming and ৳[Y] is to collect."
3. **Hero Due Card**: Rich dark graphite card displaying large `৳10,700` Due after delivery, overdue count badge, weekly collection total, and a gradient completion bar (`Collected ৳9,800 of ৳20,500 · 48% paid`).
4. **Side Widgets**:
   - `Upcoming to Deliver`: Next 3 days countdown with officer names, BD numbers, and due dates.
   - `Pipeline`: Quick count cards for Pending, Cutting Slip, and Delivered.
5. **Needs Attention Grid**: 3-per-line big cards spotlighting orders requiring immediate action or overdue payment.
6. **Weekly Collections Bar Chart**: Dynamic visual bars showing day-by-day cash intake with percentage delta.

#### Flow 4: Mobile Touch Ergonomics
1. Top bar collapses into a sleek mobile header with Raymond brand mark, search trigger, and badge drawer.
2. Persistent bottom tab bar with 4 primary destinations: **Orders**, **Airman**, **Dashboard**, **More**.
3. All touch targets strictly $\ge 44\text{px} \times 44\text{px}$.
4. Modals and action menus open as smooth bottom sheets with gesture-friendly grab handles.

---

## 3. Key Product Decisions & Trade-Offs

| Decision | Chosen Solution | Rationale & Trade-Off |
| :--- | :--- | :--- |
| **Grid Sizing** | 3 per line (Desktop) / 1 per line (Mobile) | Fits exactly 6 cards above the fold on standard displays without vertical crowding, providing optimal visual density and thumb-scan efficiency on mobile devices. |
| **Default Entry Route** | Direct to Orders (`officer-orders`) | Aligns with the tailor shop workflow where cashiers and cutting masters immediately search, verify, or register orders upon opening the app. |
| **Item & Qty Control** | Horizontal scroll chips + Inline stepper (`-` / `+`) | Replaces disruptive full-screen or dropdown selection modals with 1-tap immediate adjustments. |
| **Design System** | High-Contrast Shopify Polaris + Frosted Glass Accents | Preserves the calm, utilitarian commerce workbench while adding high-contrast dark badges and Apple-style translucency for executive feel. |
| **Custom Illustrations** | Bespoke vector SVG tailoring & military insignia | Crisp, lightweight, zero-latency rendering of BAF cap badges, scissors, tape measure, and uniform outlines. |

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        RAYMOND WEB APPLICATION                         │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ TOP BAR: Raymond Brand · Global Search (⌘K) · Notifications · Nav│  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                        │
│  ┌───────────────────────┐  ┌───────────────────────────────────────┐  │
│  │ DESKTOP SIDEBAR RAIL  │  │ MAIN CONTENT CANVAS                   │  │
│  │ • Orders (Default)    │  │                                       │  │
│  │ • Airman Orders       │  │ [ ORDERS SCREEN / DASHBOARD ]         │  │
│  │ • Dashboard           │  │ ┌───────────────────────────────────┐ │  │
│  │ • Delivery & Overdue  │  │ │ Filters: All · Pending · Done · … │ │  │
│  │ • Drafts              │  │ │ View: [☷ Grid (3/row)] [☰ Table]  │ │  │
│  │ • Customers           │  │ └───────────────────────────────────┘ │  │
│  │ • Staff Management    │  │ ┌─────────────┐ ┌─────────────┐ ...   │  │
│  │ • Settings            │  │ │ Big Card 1  │ │ Big Card 2  │       │  │
│  │                       │  │ │ ৳ Total/Due │ │ ৳ Total/Due │       │  │
│  │                       │  │ │ [Pay ৳] CTA │ │ [Slip] CTA  │       │  │
│  │                       │  │ └─────────────┘ └─────────────┘       │  │
│  └───────────────────────┘  └───────────────────────────────────────┘  │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ MOBILE BOTTOM DOCK (Mobile only): Orders · Airman · Dash · More  │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
       ┌────────────────────────────────────────────────────────┐
       │ Express Backend Server & Local JSON Store               │
       │ GET /api/state · POST /api/state (data/tailor_shop.json)│
       └────────────────────────────────────────────────────────┘
```

### Component State Mapping
- `OfficerOrdersScreen.tsx` & `AirmanOrdersScreen.tsx`: Add `viewMode: 'grid' | 'table'` state (default `'grid'`). Render 3-column responsive grid on desktop (`grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5`) and 1-column on mobile.
- `OfficerOrderForm.tsx` & `AirmanOrderForm.tsx`: Replace nested popover search with horizontal category pill scroller and inline numeric steppers.
- `DashboardScreen.tsx`: Implement the exact dark hero card, pipeline stat cards, "Needs attention" 3-box cards, and weekly revenue bar chart.
- `AppFrame.tsx`, `TopBar.tsx`, `Sidebar.tsx`: Implement mobile-responsive bottom navigation, hamburger drawer, and clean Raymond logo.
- `src/design/tokens.css` & `src/index.css`: Add frosted glass classes (`glass-panel`, `glass-card`, `glass-dark`), responsive container math, and smooth motion transitions.

---

## 5. Verification & Testing Protocol

1. **Compilation Verification**: Run `compile_applet` (`npm run build`) and `lint_applet` (`tsc --noEmit`) to verify zero syntax or typing errors.
2. **View Modes & Grid Verification**: Verify 3-per-line grid layout on desktop ($\ge 1200\text{px}$) and 1-per-line layout on mobile ($< 768\text{px}$). Verify seamless toggle between grid and table views.
3. **Item & Quantity Ergonomics**: Test adding uniform items via horizontal chip scroller and tapping `+` / `-` steppers; ensure no screen changes or dropdown glitches occur.
4. **Dashboard Precision**: Verify calculations for Due after delivery, upcoming deliveries (next 3 days), pipeline counts, and Needs Attention card payments.
5. **Full Mobile Verification**: Test all views on mobile viewport widths (375px to 430px) for touch responsiveness, navigation drawer, and sticky bottom bar.
